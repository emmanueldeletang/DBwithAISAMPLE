"""
Seed script - Create the app_users table and insert 4 default users.
Run: python seed_users.py
"""
import sys
import os

# Add parent directory for shared imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
load_dotenv()

from unified_app.services.user_service import UserService


DEFAULT_USERS = [
    {
        "username": "Emmanuel",
        "email": "edeletang@microsoft.com",
        "password": "Password12/34",
    },
    {
        "username": "Richard Prade",
        "email": "rprade@microsoft.com",
        "password": "Password12/34",
    },
    {
        "username": "Nadia",
        "email": "nadia@microsoft.com",
        "password": "Password12/34",
    },
    {
        "username": "Myrrhine",
        "email": "myrrhine@microsoft.com",
        "password": "Password12/34",
    },
]


def main():
    svc = UserService()

    # Ensure table exists
    print("Ensuring app_users table exists ...")
    svc.ensure_table()

    for u in DEFAULT_USERS:
        existing = svc.get_user_by_email(u["email"])
        if existing:
            print(f"  [skip] {u['username']} ({u['email']}) already exists")
            continue
        try:
            user_id = svc.create_user(u["username"], u["email"], u["password"])
            print(f"  [created] {u['username']} ({u['email']})  id={user_id}")
        except Exception as e:
            print(f"  [error] {u['username']}: {e}")

    print(f"\nTotal users: {svc.count_users()}")


if __name__ == "__main__":
    main()
