# Unified Multi-Database Demo Application

A single Flask application that combines all three database demos:
- **Azure SQL** - Product Catalog with Vector Search
- **PostgreSQL** - Orders and Customer Management  
- **MongoDB** - Logistics and Delivery Tracking

## Features

### Authentication
- **Microsoft Entra ID (Azure AD)** authentication via MSAL
- **Development Mode** for local testing without Azure AD configured
- Session-based user management

### Product Management (Azure SQL)
- Product catalog with CRUD operations
- **Vector Search** using Azure SQL's native VECTOR type (1536 dimensions)
- OpenAI embeddings for semantic product search
- VECTOR_DISTANCE with cosine similarity

### Order Management (PostgreSQL)
- Customer and order management
- Order creation with automatic delivery record creation
- Order status tracking
- Integration with azure_ai, vector, and pg_diskann extensions

### Logistics (MongoDB / Azure Cosmos DB)
- Delivery tracking with status updates
- Partner management
- Dispatch center for pending deliveries
- **AI-powered Natural Language Queries** via Azure OpenAI
- Package tracking (public, no login required)

## Quick Start

### 1. Install Dependencies

```bash
cd unified_app
pip install -r requirements.txt
```

### 2. Configure Environment

Create a `.env` file in the `flask-multi-db-monorepo` folder:

```env
# Database Connections
AZURE_SQL_SERVER=your-server.database.windows.net
AZURE_SQL_DATABASE=your-database

POSTGRESQL_HOST=your-postgres.postgres.database.azure.com
POSTGRESQL_DATABASE=your-database
POSTGRESQL_USER=your-user
POSTGRESQL_PASSWORD=your-password

MONGODB_CONNECTION_STRING=mongodb://...

# Azure OpenAI (for embeddings and NL queries)
AZURE_OPENAI_ENDPOINT=https://your-instance.openai.azure.com
AZURE_OPENAI_API_KEY=your-key
AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-large
AZURE_OPENAI_CHAT_DEPLOYMENT=gpt-4o

# Optional: Entra ID Authentication
AZURE_AD_CLIENT_ID=your-client-id
AZURE_AD_CLIENT_SECRET=your-client-secret
AZURE_AD_TENANT_ID=your-tenant-id

# App Configuration
SECRET_KEY=your-secret-key-for-sessions
UNIFIED_APP_PORT=5000
```

### 3. Run the Application

```bash
python app.py
```

The application will start at `http://localhost:5000`

## Development Mode

If `AZURE_AD_CLIENT_ID` is not set, the application runs in **Development Mode**:
- Login page shows "Continue as Demo User" option
- No Azure AD authentication required
- All features work with a mock user

## Application Structure

```
unified_app/
├── app.py                    # Main Flask application
├── requirements.txt          # Python dependencies
├── README.md                 # This file
└── templates/
    ├── base.html             # Base layout with navigation
    ├── dashboard.html        # Main dashboard
    ├── ask.html              # AI query interface
    ├── auth/
    │   └── login.html        # Login page
    ├── products/
    │   ├── list.html         # Product catalog
    │   ├── detail.html       # Product details
    │   ├── form.html         # Add/Edit product
    │   └── search.html       # Vector search
    ├── orders/
    │   ├── list.html         # Order list
    │   ├── detail.html       # Order details
    │   └── create.html       # Create order
    ├── customers/
    │   ├── list.html         # Customer list
    │   └── detail.html       # Customer details
    ├── deliveries/
    │   ├── list.html         # Delivery list
    │   ├── detail.html       # Delivery details
    │   ├── dispatch.html     # Dispatch center
    │   └── track.html        # Public tracking
    └── partners/
        ├── list.html         # Partner list
        └── detail.html       # Partner details
```

## Routes

### Authentication
| Route | Method | Description |
|-------|--------|-------------|
| `/login` | GET | Login page |
| `/login/dev` | GET | Development login (skip Azure AD) |
| `/login/start` | GET | Start Azure AD OAuth flow |
| `/auth/callback` | GET | Azure AD callback |
| `/logout` | GET | Logout |

### Dashboard
| Route | Method | Description |
|-------|--------|-------------|
| `/` | GET | Main dashboard with stats |

### Products (Azure SQL)
| Route | Method | Description |
|-------|--------|-------------|
| `/products` | GET | Product list |
| `/products/<id>` | GET | Product details |
| `/products/add` | GET/POST | Add product |
| `/products/<id>/edit` | GET/POST | Edit product |
| `/products/<id>/delete` | POST | Delete product |
| `/products/search` | GET | Vector search |

### Orders (PostgreSQL)
| Route | Method | Description |
|-------|--------|-------------|
| `/orders` | GET | Order list |
| `/orders/<id>` | GET | Order details |
| `/orders/create` | GET/POST | Create order |
| `/orders/<id>/status` | POST | Update order status |

### Customers (PostgreSQL)
| Route | Method | Description |
|-------|--------|-------------|
| `/customers` | GET | Customer list |
| `/customers/<id>` | GET | Customer details |

### Deliveries (MongoDB)
| Route | Method | Description |
|-------|--------|-------------|
| `/deliveries` | GET | Delivery list |
| `/deliveries/<id>` | GET | Delivery details |
| `/deliveries/dispatch` | GET | Dispatch center |
| `/deliveries/<id>/dispatch` | POST | Dispatch delivery |
| `/deliveries/<id>/status` | POST | Update delivery status |
| `/track` | GET | Public tracking (no auth) |

### Partners (MongoDB)
| Route | Method | Description |
|-------|--------|-------------|
| `/partners` | GET | Partner list |
| `/partners/<id>` | GET | Partner details |

### AI Queries
| Route | Method | Description |
|-------|--------|-------------|
| `/ask` | GET/POST | Natural language query interface |
| `/api/ask` | POST | API endpoint for NL queries |

## API Endpoints

```bash
# Get all products
GET /api/products

# Get product by SKU
GET /api/products/<sku>

# Create delivery
POST /api/deliveries
Content-Type: application/json
{
  "order_id": "uuid",
  "customer_name": "John Doe",
  "address": "123 Main St",
  "city": "Paris"
}

# Natural language query
POST /api/ask
Content-Type: application/json
{
  "question": "How many pending deliveries are there?"
}
```

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    Unified Flask App                         │
│                     (Port 5000)                              │
├──────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐          │
│  │  Products   │  │   Orders    │  │  Logistics  │          │
│  │   Routes    │  │   Routes    │  │   Routes    │          │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘          │
│         │                │                │                  │
│  ┌──────▼──────┐  ┌──────▼──────┐  ┌──────▼──────┐          │
│  │  Product    │  │   Order     │  │  Delivery   │          │
│  │  Service    │  │  Service    │  │  Service    │          │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘          │
└─────────┼────────────────┼────────────────┼──────────────────┘
          │                │                │
    ┌─────▼─────┐    ┌─────▼─────┐    ┌─────▼─────┐
    │ Azure SQL │    │PostgreSQL │    │  MongoDB  │
    │  (VECTOR) │    │ (pgvector)│    │(Cosmos DB)│
    └───────────┘    └───────────┘    └───────────┘
```

## License

MIT
