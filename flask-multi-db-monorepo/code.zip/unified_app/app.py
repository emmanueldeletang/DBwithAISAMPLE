"""
Unified Multi-Database Demo Application
Combines Product, Order, and Logistics functionality with Entra ID authentication
"""
import os
import sys
import uuid
from functools import wraps

# Add parent directory for shared imports and sibling app imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, g
from dotenv import load_dotenv
import msal

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'unified-app-secret-key-change-in-production')
app.config['SESSION_TYPE'] = 'filesystem'

# ============================================================================
# Azure AD / Entra ID Configuration
# ============================================================================

AZURE_AD_CLIENT_ID = os.getenv('AZURE_AD_CLIENT_ID', '')
AZURE_AD_CLIENT_SECRET = os.getenv('AZURE_AD_CLIENT_SECRET', '')
AZURE_AD_TENANT_ID = os.getenv('AZURE_AD_TENANT_ID', 'common')
AZURE_AD_AUTHORITY = f"https://login.microsoftonline.com/{AZURE_AD_TENANT_ID}"
AZURE_AD_REDIRECT_PATH = "/auth/callback"
AZURE_AD_SCOPE = ["User.Read"]

# For development without Azure AD configured
DEV_MODE = not AZURE_AD_CLIENT_ID


def _build_msal_app(cache=None):
    """Build MSAL confidential client application."""
    return msal.ConfidentialClientApplication(
        AZURE_AD_CLIENT_ID,
        authority=AZURE_AD_AUTHORITY,
        client_credential=AZURE_AD_CLIENT_SECRET,
        token_cache=cache
    )


def _get_token_from_cache(scope=None):
    """Get token from cache."""
    cache = _load_cache()
    cca = _build_msal_app(cache)
    accounts = cca.get_accounts()
    if accounts:
        result = cca.acquire_token_silent(scope or AZURE_AD_SCOPE, account=accounts[0])
        _save_cache(cache)
        return result
    return None


def _load_cache():
    """Load token cache from session."""
    cache = msal.SerializableTokenCache()
    if session.get("token_cache"):
        cache.deserialize(session["token_cache"])
    return cache


def _save_cache(cache):
    """Save token cache to session."""
    if cache.has_state_changed:
        session["token_cache"] = cache.serialize()


def login_required(f):
    """Decorator to require login."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if DEV_MODE:
            # Development mode - use mock user
            g.user = {
                'name': 'Dev User',
                'email': 'dev@localhost',
                'preferred_username': 'dev@localhost'
            }
            return f(*args, **kwargs)
        
        if not session.get("user"):
            return redirect(url_for("login"))
        
        g.user = session.get("user")
        return f(*args, **kwargs)
    return decorated_function


# ============================================================================
# Import Services
# ============================================================================

# Product Services (Azure SQL)
from product_app.services.product_service import ProductService
from product_app.services.search_service import ProductSearchService

# Order Services (PostgreSQL)
from order_app.services.customer_service import CustomerService
from order_app.services.order_service import OrderService
from order_app.services.nl_query_service import NaturalLanguageQueryService as PostgresNLQuery

# Logistics Services (MongoDB)
from logistics_app.services.partner_service import PartnerService
from logistics_app.services.delivery_service import DeliveryService
from logistics_app.services.nl_query_service import NLQueryService as MongoNLQuery

# Product NL Query Service (Azure SQL)
from product_app.services.nl_query_service import NLQueryService as AzureSQLNLQuery

# Initialize services
product_service = ProductService()
product_search_service = ProductSearchService()

customer_service = CustomerService()
order_service = OrderService()
postgres_nl_query = PostgresNLQuery()

partner_service = PartnerService()
delivery_service = DeliveryService()
mongo_nl_query = MongoNLQuery()
azuresql_nl_query = AzureSQLNLQuery()


# ============================================================================
# Context Processor - Make user available in all templates
# ============================================================================

@app.context_processor
def inject_user():
    """Inject user into all templates."""
    return dict(
        current_user=getattr(g, 'user', None),
        dev_mode=DEV_MODE
    )


# ============================================================================
# Authentication Routes
# ============================================================================

@app.route('/login')
def login():
    """Login page."""
    if session.get('user'):
        return redirect(url_for('index'))
    return render_template('auth/login.html')


@app.route('/login/dev')
def login_dev():
    """Development login - skip Azure AD."""
    session['user'] = {
        'name': 'Dev User',
        'email': 'dev@localhost',
        'preferred_username': 'dev@localhost'
    }
    flash('Logged in as Dev User (development mode)', 'info')
    return redirect(url_for('index'))


@app.route('/login/start')
def login_start():
    """Start the Azure AD login flow."""
    if DEV_MODE:
        return redirect(url_for('login'))
    
    session["state"] = str(uuid.uuid4())
    
    cca = _build_msal_app()
    auth_url = cca.get_authorization_request_url(
        AZURE_AD_SCOPE,
        state=session["state"],
        redirect_uri=request.url_root.rstrip('/') + AZURE_AD_REDIRECT_PATH
    )
    
    return redirect(auth_url)


@app.route('/auth/callback')
def auth_callback():
    """Handle Azure AD callback."""
    if DEV_MODE:
        return redirect(url_for('index'))
    
    if request.args.get('state') != session.get("state"):
        return redirect(url_for('login'))
    
    if "error" in request.args:
        flash(f"Login error: {request.args.get('error_description', 'Unknown error')}", 'error')
        return redirect(url_for('login'))
    
    if request.args.get('code'):
        cache = _load_cache()
        cca = _build_msal_app(cache)
        
        result = cca.acquire_token_by_authorization_code(
            request.args['code'],
            scopes=AZURE_AD_SCOPE,
            redirect_uri=request.url_root.rstrip('/') + AZURE_AD_REDIRECT_PATH
        )
        
        if "error" in result:
            flash(f"Login failed: {result.get('error_description', 'Unknown error')}", 'error')
            return redirect(url_for('login'))
        
        _save_cache(cache)
        
        # Store user info in session
        session["user"] = result.get("id_token_claims")
        
        flash(f"Welcome, {session['user'].get('name', 'User')}!", 'success')
    
    return redirect(url_for('index'))


@app.route('/logout')
def logout():
    """Logout user."""
    session.clear()
    
    if DEV_MODE:
        flash('Logged out', 'info')
        return redirect(url_for('login'))
    
    return redirect(
        f"{AZURE_AD_AUTHORITY}/oauth2/v2.0/logout"
        f"?post_logout_redirect_uri={request.url_root}"
    )


# ============================================================================
# Main Dashboard
# ============================================================================

@app.route('/')
@login_required
def index():
    """Main dashboard."""
    try:
        # Get counts from all databases
        products_count = product_service.count_products()
    except Exception:
        products_count = 0
    
    try:
        customers_count = customer_service.count_customers()
    except Exception:
        customers_count = 0
    
    try:
        orders_count = order_service.count_orders()
    except Exception:
        orders_count = 0
    
    try:
        deliveries_count = delivery_service.count_deliveries()
    except Exception:
        deliveries_count = 0
    
    try:
        pending_deliveries = delivery_service.count_by_status('pending')
    except Exception:
        pending_deliveries = 0
    
    try:
        partners_count = partner_service.count_partners()
    except Exception:
        partners_count = 0
    
    # Build stats dict for template
    stats = {
        'products': products_count,
        'customers': customers_count,
        'orders': orders_count,
        'deliveries': deliveries_count,
        'pending_deliveries': pending_deliveries,
        'partners': partners_count
    }
    
    return render_template('dashboard.html', stats=stats)


# ============================================================================
# PRODUCTS (Azure SQL)
# ============================================================================

@app.route('/products')
@login_required
def products():
    """Product catalog with filtering."""
    page = request.args.get('page', 1, type=int)
    per_page = 12
    category = request.args.get('category', '')
    search = request.args.get('search', '')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    sort = request.args.get('sort', 'created_at')
    order = request.args.get('order', 'DESC')
    
    products_list = product_service.get_products_filtered(
        page=page, per_page=per_page, category=category,
        search=search, min_price=min_price, max_price=max_price,
        sort=sort, order=order
    )
    total = product_service.count_products(category=category, search=search)
    total_pages = (total + per_page - 1) // per_page
    categories = product_service.get_categories()
    
    return render_template('products/list.html',
                         products=products_list,
                         page=page,
                         total_pages=total_pages,
                         total=total,
                         categories=categories,
                         current_category=category,
                         search=search,
                         min_price=min_price,
                         max_price=max_price,
                         sort=sort,
                         order=order)


@app.route('/products/<product_id>')
@login_required
def product_detail(product_id):
    """Product detail page."""
    product = product_service.get_product_by_sku(product_id)
    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('products'))
    
    return render_template('products/detail.html', product=product)


@app.route('/products/add', methods=['GET', 'POST'])
@login_required
def add_product():
    """Add new product."""
    if request.method == 'POST':
        data = {
            'sku': request.form['sku'],
            'name': request.form['name'],
            'description': request.form['description'],
            'price': float(request.form['price']),
            'category': request.form.get('category', ''),
            'stock': int(request.form.get('stock_quantity', 0))
        }
        
        try:
            product_service.create_product(data)
            flash(f'Product "{data["name"]}" created successfully!', 'success')
            return redirect(url_for('product_detail', product_id=data['sku']))
        except Exception as e:
            flash(f'Error creating product: {str(e)}', 'error')
    
    return render_template('products/form.html', product=None)


@app.route('/products/<product_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    """Edit product."""
    product = product_service.get_product_by_sku(product_id)
    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('products'))
    
    if request.method == 'POST':
        data = {
            'name': request.form['name'],
            'description': request.form['description'],
            'price': float(request.form['price']),
            'category': request.form.get('category', ''),
            'stock': int(request.form.get('stock_quantity', 0))
        }
        
        try:
            product_service.update_product(product_id, data)
            flash('Product updated successfully!', 'success')
            return redirect(url_for('product_detail', product_id=product_id))
        except Exception as e:
            flash(f'Error updating product: {str(e)}', 'error')
    
    return render_template('products/form.html', product=product)


@app.route('/products/<product_id>/delete', methods=['POST'])
@login_required
def delete_product(product_id):
    """Delete product."""
    try:
        product_service.delete_product(product_id)
        flash('Product deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting product: {str(e)}', 'error')
    
    return redirect(url_for('products'))
@app.route('/products/search')
@login_required
def search_products():
    """Search products."""
    query = request.args.get('q', '')
    limit = request.args.get('limit', 10, type=int)
    
    results = []
    
    if query:
        try:
            results = product_search_service.vector_search(query, limit=limit)
        except Exception as e:
            flash(f'Search error: {str(e)}', 'error')
    
    return render_template('products/search.html',
                         results=results,
                         query=query,
                         limit=limit)


# ============================================================================
# ORDERS (PostgreSQL)
# ============================================================================

@app.route('/orders')
@login_required
def orders():
    """Order list."""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    per_page = 20
    
    orders_list = order_service.get_all_orders(page=page, per_page=per_page, status=status)
    total = order_service.count_orders(status=status)
    total_pages = (total + per_page - 1) // per_page
    
    return render_template('orders/list.html',
                         orders=orders_list,
                         page=page,
                         total_pages=total_pages,
                         total=total,
                         status_filter=status)


@app.route('/orders/<order_id>')
@login_required
def order_detail(order_id):
    """Order detail page."""
    order = order_service.get_order_by_id(order_id)
    if not order:
        flash('Order not found', 'error')
        return redirect(url_for('orders'))
    
    order_items = order_service.get_order_items(order_id)
    customer = customer_service.get_customer_by_id(order['customer_id'])
    
    # Get delivery info from MongoDB
    delivery = delivery_service.get_by_order_id(order_id)
    
    return render_template('orders/detail.html',
                         order=order,
                         order_items=order_items,
                         customer=customer,
                         delivery=delivery)


@app.route('/orders/<order_id>/status', methods=['POST'])
@login_required
def update_order_status(order_id):
    """Update order status."""
    new_status = request.form.get('status')
    if new_status:
        try:
            order_service.update_order_status(order_id, new_status)
            flash(f'Order status updated to {new_status}', 'success')
        except Exception as e:
            flash(f'Error updating status: {str(e)}', 'error')
    return redirect(url_for('order_detail', order_id=order_id))


@app.route('/orders/create', methods=['GET', 'POST'])
@login_required
def create_order():
    """Create new order."""
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        product_skus = request.form.getlist('product_sku')
        quantities = request.form.getlist('quantity')
        
        items = []
        for sku, qty in zip(product_skus, quantities):
            if sku and int(qty) > 0:
                items.append({'product_sku': sku, 'quantity': int(qty)})
        
        if not items:
            flash('Please add at least one product', 'error')
            return redirect(url_for('create_order'))
        
        try:
            # Get customer info for delivery
            customer = customer_service.get_customer_by_id(customer_id)
            
            # Create order in PostgreSQL
            order_id = order_service.create_order(customer_id, items, 
                                                  ProductAPIInternal(), 
                                                  customer_info=None)  # Don't use built-in logistics API
            
            # Create delivery in MongoDB for dispatch
            if customer:
                try:
                    delivery_data = {
                        'order_id': order_id,
                        'customer_name': f"{customer.get('first_name', '')} {customer.get('last_name', '')}".strip(),
                        'address': customer.get('address', '') or f"{customer.get('city', '')}, {customer.get('country', '')}",
                        'city': customer.get('city', ''),
                        'postal_code': customer.get('postal_code', ''),
                        'country': customer.get('country', 'France'),
                        'notes': f"Order {order_id[:8]}..."
                    }
                    delivery_id = delivery_service.create_delivery(delivery_data)
                    flash(f'Order created successfully! Delivery {delivery_id} added to dispatch.', 'success')
                except Exception as e:
                    flash(f'Order created but delivery creation failed: {str(e)}', 'warning')
            else:
                flash('Order created successfully!', 'success')
            
            return redirect(url_for('order_detail', order_id=order_id))
        except Exception as e:
            flash(f'Error creating order: {str(e)}', 'error')
    
    customers = customer_service.get_all_customers(page=1, per_page=100)
    products_list = product_service.get_all_products(page=1, per_page=100)
    
    return render_template('orders/create.html',
                         customers=customers,
                         products=products_list)


class ProductAPIInternal:
    """Internal product API that directly uses the service."""
    def get_product_by_sku(self, sku):
        return product_service.get_product_by_sku(sku)
    
    def get_all_products(self):
        return product_service.get_all_products(page=1, per_page=100)


# ============================================================================
# CUSTOMERS (PostgreSQL)
# ============================================================================

@app.route('/customers')
@login_required
def customers():
    """Customer list."""
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    customers_list = customer_service.get_all_customers(page=page, per_page=per_page)
    total = customer_service.count_customers()
    total_pages = (total + per_page - 1) // per_page
    
    return render_template('customers/list.html',
                         customers=customers_list,
                         page=page,
                         total_pages=total_pages,
                         total=total)


@app.route('/customers/<customer_id>')
@login_required
def customer_detail(customer_id):
    """Customer detail page."""
    customer = customer_service.get_customer_by_id(customer_id)
    if not customer:
        flash('Customer not found', 'error')
        return redirect(url_for('customers'))
    
    customer_orders = order_service.get_orders_by_customer(customer_id)
    total_spent = sum(float(o.get('total_amount', 0)) for o in customer_orders)
    
    return render_template('customers/detail.html',
                         customer=customer,
                         orders=customer_orders,
                         total_spent=total_spent)


# ============================================================================
# DELIVERIES (MongoDB)
# ============================================================================

@app.route('/deliveries')
@login_required
def deliveries():
    """Delivery list - shows deliveries with partners assigned."""
    status_filter = request.args.get('status', '')
    deliveries_list = delivery_service.get_assigned_deliveries(status=status_filter)
    
    # Enrich deliveries with partner names
    partners_cache = {}
    for delivery in deliveries_list:
        partner_id = delivery.get('partner_id')
        if partner_id:
            if partner_id not in partners_cache:
                partner = partner_service.get_partner_by_id(partner_id)
                partners_cache[partner_id] = partner.get('name') if partner else None
            delivery['partner_name'] = partners_cache[partner_id]
        else:
            delivery['partner_name'] = None
    
    # Count unassigned for dispatch badge
    unassigned_count = len(delivery_service.get_unassigned_deliveries())
    
    return render_template('deliveries/list.html',
                         deliveries=deliveries_list,
                         status_filter=status_filter,
                         unassigned_count=unassigned_count)


@app.route('/deliveries/<delivery_id>')
@login_required
def delivery_detail(delivery_id):
    """Delivery detail page."""
    delivery = delivery_service.get_delivery_by_id(delivery_id)
    if not delivery:
        flash('Delivery not found', 'error')
        return redirect(url_for('deliveries'))
    
    partner = None
    if delivery.get('partner_id'):
        partner = partner_service.get_partner_by_id(delivery['partner_id'])
    
    return render_template('deliveries/detail.html',
                         delivery=delivery,
                         partner=partner)


@app.route('/deliveries/dispatch')
@login_required
def dispatch():
    """Dispatch center - deliveries without partner assigned."""
    unassigned_deliveries = delivery_service.get_unassigned_deliveries()
    partners = partner_service.get_all_partners(active_only=True)
    
    return render_template('deliveries/dispatch.html',
                         pending_deliveries=unassigned_deliveries,
                         partners=partners)


@app.route('/deliveries/<delivery_id>/dispatch', methods=['POST'])
@login_required
def dispatch_delivery(delivery_id):
    """Dispatch a delivery to a partner."""
    partner_id = request.form.get('partner_id')
    
    if not partner_id:
        flash('Please select a delivery partner', 'error')
        return redirect(url_for('dispatch'))
    
    try:
        # Get partner name for the flash message
        partner = partner_service.get_partner_by_id(partner_id)
        partner_name = partner.get('name') if partner else partner_id
        
        delivery_service.assign_partner(delivery_id, partner_id)
        delivery_service.update_status(delivery_id, 'picked_up', 
                                       f'Dispatched to {partner_name}', 'Warehouse')
        flash(f'Delivery dispatched to {partner_name}!', 'success')
    except Exception as e:
        flash(f'Error dispatching: {str(e)}', 'error')
    
    return redirect(url_for('dispatch'))


@app.route('/track')
def track():
    """Public tracking page (no login required)."""
    tracking_number = request.args.get('tracking', '')
    delivery = None
    
    if tracking_number:
        # Try by tracking number first
        delivery = delivery_service.get_by_tracking_number(tracking_number)
        # If not found, try by order ID
        if not delivery:
            delivery = delivery_service.get_by_order_id(tracking_number)
    
    return render_template('deliveries/track.html',
                         tracking_number=tracking_number,
                         delivery=delivery)


@app.route('/deliveries/<delivery_id>/status', methods=['POST'])
@login_required
def update_delivery_status(delivery_id):
    """Update delivery status."""
    new_status = request.form.get('status')
    if new_status:
        try:
            delivery_service.update_status(delivery_id, new_status)
            flash(f'Delivery status updated to {new_status}', 'success')
        except Exception as e:
            flash(f'Error updating status: {str(e)}', 'error')
    return redirect(url_for('delivery_detail', delivery_id=delivery_id))


# ============================================================================
# PARTNERS (MongoDB)
# ============================================================================

@app.route('/partners')
@login_required
def partners():
    """Partner list with delivery stats."""
    partners_list = partner_service.get_all_partners()
    
    # Calculate delivery stats for each partner
    for partner in partners_list:
        partner_id = partner.get('partner_id') or partner.get('_id')
        partner_deliveries = delivery_service.get_deliveries_by_partner(partner_id)
        
        total = len(partner_deliveries)
        completed = sum(1 for d in partner_deliveries if d.get('status') == 'delivered')
        active = sum(1 for d in partner_deliveries if d.get('status') in ['pending', 'picked_up', 'in_transit', 'out_for_delivery'])
        
        partner['total_deliveries'] = total
        partner['active_deliveries'] = active
        partner['success_rate'] = round((completed / total * 100)) if total > 0 else 0
    
    return render_template('partners/list.html', partners=partners_list)


@app.route('/partners/<partner_id>')
@login_required
def partner_detail(partner_id):
    """Partner detail page."""
    partner = partner_service.get_partner_by_id(partner_id)
    if not partner:
        flash('Partner not found', 'error')
        return redirect(url_for('partners'))
    
    partner_deliveries = delivery_service.get_deliveries_by_partner(partner_id)
    
    # Calculate stats
    total = len(partner_deliveries)
    completed = sum(1 for d in partner_deliveries if d.get('status') == 'delivered')
    failed = sum(1 for d in partner_deliveries if d.get('status') == 'failed')
    in_progress = total - completed - failed
    
    stats = {
        'total': total,
        'completed': completed,
        'failed': failed,
        'in_progress': in_progress
    }
    
    return render_template('partners/detail.html',
                         partner=partner,
                         deliveries=partner_deliveries,
                         stats=stats)


# ============================================================================
# AI / NATURAL LANGUAGE QUERIES
# ============================================================================

@app.route('/ask', methods=['GET', 'POST'])
@login_required
def ask_question():
    """Natural language query interface for PostgreSQL, MongoDB, and Azure SQL."""
    result = None
    question = ''
    error = None
    database = 'postgres'  # Default to PostgreSQL
    
    if request.method == 'POST':
        question = request.form.get('question', '').strip()
        database = request.form.get('database', 'postgres')
        
        if question:
            try:
                if database == 'mongodb':
                    result = mongo_nl_query.ask(question)
                elif database == 'azuresql':
                    result = azuresql_nl_query.query(question)
                else:
                    result = postgres_nl_query.query(question)
                
                if not result.get('success', False):
                    error = result.get('error', 'Unknown error')
            except Exception as e:
                error = str(e)
    
    # Get suggested questions for all databases
    postgres_suggestions = postgres_nl_query.get_example_queries()
    mongo_suggestions = mongo_nl_query.get_suggested_questions()
    azuresql_suggestions = azuresql_nl_query.get_suggested_questions()
    
    return render_template('ask.html',
                         question=question,
                         result=result,
                         error=error,
                         database=database,
                         postgres_suggestions=postgres_suggestions,
                         mongo_suggestions=mongo_suggestions,
                         azuresql_suggestions=azuresql_suggestions)


# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.route('/api/products')
@login_required
def api_products():
    """API: Get all products."""
    products_list = product_service.get_all_products(page=1, per_page=100)
    return jsonify(products_list)


@app.route('/api/products/<sku>')
@login_required
def api_product(sku):
    """API: Get product by SKU."""
    product = product_service.get_product_by_sku(sku)
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    return jsonify(product)


@app.route('/api/products/<sku>/image')
def api_product_image(sku):
    """API: Proxy product image from private blob storage."""
    from azure.storage.blob import BlobServiceClient
    from flask import Response
    
    connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
    container_name = os.getenv('AZURE_STORAGE_CONTAINER', 'product-images')
    
    if not connection_string:
        account_name = os.getenv('AZURE_STORAGE_ACCOUNT')
        account_key = os.getenv('AZURE_STORAGE_KEY')
        if not account_name or not account_key:
            return '', 404
        account_url = f"https://{account_name}.blob.core.windows.net"
        blob_service_client = BlobServiceClient(account_url, credential=account_key)
    else:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    
    blob_name = f"products/{sku.lower()}.png"
    
    try:
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client(blob_name)
        
        # Download blob data
        blob_data = blob_client.download_blob().readall()
        
        return Response(
            blob_data,
            mimetype='image/png',
            headers={
                'Cache-Control': 'public, max-age=86400',  # Cache for 1 day
                'Content-Disposition': f'inline; filename="{sku}.png"'
            }
        )
    except Exception:
        return '', 404


@app.route('/api/deliveries', methods=['POST'])
@login_required
def api_create_delivery():
    """API: Create delivery from order."""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'JSON data required'}), 400
    
    required = ['order_id', 'customer_name', 'address', 'city']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'Missing: {field}'}), 400
    
    try:
        delivery_id = delivery_service.create_delivery(data)
        delivery = delivery_service.get_delivery_by_id(delivery_id)
        return jsonify({
            'success': True,
            'delivery_id': delivery_id,
            'tracking_number': delivery.get('tracking_number') if delivery else None
        }), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/ask', methods=['POST'])
@login_required
def api_ask():
    """API: Natural language query for PostgreSQL, MongoDB, or Azure SQL."""
    data = request.get_json()
    
    if not data or not data.get('question'):
        return jsonify({'error': 'Question is required'}), 400
    
    database = data.get('database', 'postgres')
    
    try:
        if database == 'mongodb':
            result = mongo_nl_query.ask(data['question'])
        elif database == 'azuresql':
            result = azuresql_nl_query.query(data['question'])
        else:
            result = postgres_nl_query.query(data['question'])
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Main
# ============================================================================

if __name__ == '__main__':
    port = int(os.getenv('UNIFIED_APP_PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'true').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)
