from flask import Flask, jsonify
import pytest
from shared.database.azure_sql import get_db_session
from apps.azure-sql-app.models.user import User

@pytest.fixture
def client():
    app = Flask(__name__)
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    with app.app_context():
        yield app.test_client()

def test_create_user(client):
    response = client.post('/api/users', json={
        'sku': '12345',
        'name': 'Test User',
        'description': 'A user for testing',
        'price': 10.99,
        'currency': 'USD',
        'tags': ['test', 'user'],
        'stock': 100,
        'created_at': '2023-01-01T00:00:00Z',
        'embeddings': [0.1, 0.2, 0.3]
    })
    assert response.status_code == 201
    assert 'id' in response.json

def test_get_user(client):
    response = client.get('/api/users/1')
    assert response.status_code == 200
    assert 'name' in response.json

def test_search_users(client):
    response = client.get('/api/users/search?query=Test')
    assert response.status_code == 200
    assert isinstance(response.json, list)