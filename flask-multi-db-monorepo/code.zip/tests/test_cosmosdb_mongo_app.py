from flask import Flask, jsonify
import pytest
from apps.cosmosdb-mongo-app.app import create_app
from shared.database.cosmosdb_mongo import get_db

@pytest.fixture
def app():
    app = create_app()
    app.config['TESTING'] = True
    with app.app_context():
        yield app

@pytest.fixture
def client(app):
    return app.test_client()

def test_create_document(client):
    response = client.post('/api/documents', json={'name': 'Test Document', 'content': 'This is a test.'})
    assert response.status_code == 201
    assert 'id' in response.json

def test_get_document(client):
    response = client.post('/api/documents', json={'name': 'Test Document', 'content': 'This is a test.'})
    document_id = response.json['id']
    
    response = client.get(f'/api/documents/{document_id}')
    assert response.status_code == 200
    assert response.json['name'] == 'Test Document'

def test_update_document(client):
    response = client.post('/api/documents', json={'name': 'Test Document', 'content': 'This is a test.'})
    document_id = response.json['id']
    
    response = client.put(f'/api/documents/{document_id}', json={'name': 'Updated Document', 'content': 'Updated content.'})
    assert response.status_code == 200
    
    response = client.get(f'/api/documents/{document_id}')
    assert response.json['name'] == 'Updated Document'

def test_delete_document(client):
    response = client.post('/api/documents', json={'name': 'Test Document', 'content': 'This is a test.'})
    document_id = response.json['id']
    
    response = client.delete(f'/api/documents/{document_id}')
    assert response.status_code == 204
    
    response = client.get(f'/api/documents/{document_id}')
    assert response.status_code == 404

def test_search_documents(client):
    client.post('/api/documents', json={'name': 'Test Document 1', 'content': 'This is a test.'})
    client.post('/api/documents', json={'name': 'Test Document 2', 'content': 'Another test.'})
    
    response = client.get('/api/documents/search?query=Test')
    assert response.status_code == 200
    assert len(response.json) == 2