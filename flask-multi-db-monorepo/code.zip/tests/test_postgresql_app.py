from flask import Flask, jsonify
import pytest
from apps.postgresql-app.app import create_app
from shared.database.postgresql import db

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://user:password@localhost/test_db'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client

    with app.app_context():
        db.drop_all()

def test_create_product(client):
    response = client.post('/api/products', json={
        'name': 'Test Product',
        'description': 'This is a test product.',
        'price': 19.99,
        'currency': 'USD',
        'tags': ['test', 'product'],
        'stock': 100
    })
    assert response.status_code == 201
    assert response.json['name'] == 'Test Product'

def test_get_products(client):
    response = client.get('/api/products')
    assert response.status_code == 200
    assert isinstance(response.json, list)

def test_update_product(client):
    response = client.post('/api/products', json={
        'name': 'Update Product',
        'description': 'This product will be updated.',
        'price': 29.99,
        'currency': 'USD',
        'tags': ['update'],
        'stock': 50
    })
    product_id = response.json['id']
    
    response = client.put(f'/api/products/{product_id}', json={
        'name': 'Updated Product',
        'description': 'This product has been updated.',
        'price': 39.99,
        'currency': 'USD',
        'tags': ['updated'],
        'stock': 30
    })
    assert response.status_code == 200
    assert response.json['name'] == 'Updated Product'

def test_search_products(client):
    response = client.get('/api/products/search?query=Test')
    assert response.status_code == 200
    assert isinstance(response.json, list)