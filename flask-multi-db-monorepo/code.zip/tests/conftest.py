import pytest

@pytest.fixture(scope='session')
def test_client():
    from apps.azure-sql-app.app import create_app
    app = create_app()
    with app.test_client() as client:
        yield client

@pytest.fixture(scope='session')
def postgresql_test_client():
    from apps.postgresql-app.app import create_app
    app = create_app()
    with app.test_client() as client:
        yield client

@pytest.fixture(scope='session')
def cosmosdb_test_client():
    from apps.cosmosdb-mongo-app.app import create_app
    app = create_app()
    with app.test_client() as client:
        yield client