"""MCP Server for Azure SQL Products Database."""
