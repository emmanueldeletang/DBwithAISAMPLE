"""
MCP Mongo Server - MongoDB with natural language queries
"""
