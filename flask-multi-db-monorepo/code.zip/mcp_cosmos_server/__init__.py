"""
MCP Cosmos Server - Azure Cosmos DB NoSQL with natural language queries
"""
