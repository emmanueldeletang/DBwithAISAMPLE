-- ============================================================================
-- Azure SQL Database - Product Catalog Schema
-- Database: productcatalog
-- ============================================================================

-- Enable vector support (if available in your Azure SQL tier)
-- Note: Vector support requires Azure SQL Database with specific features enabled

-- Drop tables if they exist (for clean reinstall)
IF OBJECT_ID('products', 'U') IS NOT NULL DROP TABLE products;
IF OBJECT_ID('categories', 'U') IS NOT NULL DROP TABLE categories;

-- ============================================================================
-- Categories Table
-- ============================================================================
CREATE TABLE categories (
    category_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    description NVARCHAR(500),
    parent_category_id INT NULL,
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    FOREIGN KEY (parent_category_id) REFERENCES categories(category_id)
);

-- ============================================================================
-- Products Table with Vector Column
-- ============================================================================
CREATE TABLE products (
    sku NVARCHAR(50) PRIMARY KEY,
    name NVARCHAR(200) NOT NULL,
    description NVARCHAR(MAX),
    price DECIMAL(10, 2) NOT NULL,
    currency NVARCHAR(3) DEFAULT 'EUR',
    tags NVARCHAR(500),
    stock INT DEFAULT 0,
    category NVARCHAR(100),
    category_id INT NULL,
    
    -- Vector column for embeddings (3072 dimensions for text-embedding-3-large)
    -- Note: VECTOR type requires Azure SQL with vector support
    description_embedding NVARCHAR(MAX), -- JSON array of floats (fallback if VECTOR not available)
    -- description_embedding VECTOR(3072), -- Use this if VECTOR type is available
    
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

-- ============================================================================
-- Indexes
-- ============================================================================

-- Index for category lookup
CREATE INDEX IX_products_category ON products(category);
CREATE INDEX IX_products_category_id ON products(category_id);

-- Index for price range queries
CREATE INDEX IX_products_price ON products(price);

-- Index for stock queries
CREATE INDEX IX_products_stock ON products(stock);

-- Full-text index for keyword search (if full-text is enabled)
-- CREATE FULLTEXT CATALOG ProductCatalog AS DEFAULT;
-- CREATE FULLTEXT INDEX ON products(name, description, tags) KEY INDEX PK_products;

-- Vector index for similarity search (if VECTOR type is available)
-- CREATE VECTOR INDEX IX_products_embedding ON products(description_embedding)
-- WITH (metric = 'cosine', type = 'diskann');

-- ============================================================================
-- Seed Data
-- ============================================================================

-- Insert categories
INSERT INTO categories (name, description) VALUES
('Electronics', 'Electronic devices and accessories'),
('Computers', 'Laptops, desktops, and computer accessories'),
('Audio', 'Headphones, speakers, and audio equipment'),
('Gaming', 'Gaming consoles, accessories, and games'),
('Accessories', 'Various tech accessories');

-- Insert sample products
INSERT INTO products (sku, name, description, price, currency, tags, stock, category) VALUES
('LAPTOP-PRO-001', 'ProBook Laptop 15"', 'Professional laptop with 15.6" Full HD display, Intel Core i7 processor, 16GB RAM, 512GB SSD. Perfect for business and productivity. Long battery life up to 12 hours.', 1299.99, 'EUR', 'laptop,professional,business,intel,portable', 50, 'Computers'),

('LAPTOP-GAMING-001', 'GameMaster X17', 'High-performance gaming laptop with 17.3" 144Hz display, RTX 4070 graphics, 32GB RAM, 1TB NVMe SSD. RGB keyboard and advanced cooling system.', 2199.99, 'EUR', 'laptop,gaming,rtx,high-performance,rgb', 25, 'Gaming'),

('HEADPHONES-WL-001', 'SoundWave Pro Wireless', 'Premium wireless over-ear headphones with active noise cancellation, 40-hour battery life, Bluetooth 5.3, and Hi-Res Audio support. Comfortable memory foam ear cushions.', 299.99, 'EUR', 'headphones,wireless,anc,bluetooth,audio', 100, 'Audio'),

('HEADPHONES-GAMING-001', 'ProGamer Headset 7.1', 'Professional gaming headset with 7.1 surround sound, detachable microphone, RGB lighting, and memory foam cushions. Compatible with PC, PlayStation, and Xbox.', 149.99, 'EUR', 'headphones,gaming,7.1,surround,rgb,microphone', 75, 'Gaming'),

('KEYBOARD-MECH-001', 'MechType Elite', 'Mechanical gaming keyboard with Cherry MX Brown switches, per-key RGB lighting, aluminum frame, USB-C connectivity, and dedicated macro keys.', 179.99, 'EUR', 'keyboard,mechanical,gaming,rgb,cherry-mx', 60, 'Gaming'),

('MOUSE-GAMING-001', 'PrecisionX Gaming Mouse', 'High-precision gaming mouse with 25,000 DPI optical sensor, 8 programmable buttons, RGB lighting, and ergonomic design. Lightweight at just 65g.', 89.99, 'EUR', 'mouse,gaming,rgb,precision,lightweight', 120, 'Gaming'),

('MONITOR-4K-001', 'UltraView 27" 4K', '27-inch 4K UHD IPS monitor with HDR400, 99% sRGB coverage, USB-C with 65W power delivery, adjustable stand, and built-in speakers.', 549.99, 'EUR', 'monitor,4k,uhd,hdr,usb-c,professional', 40, 'Computers'),

('SPEAKER-BT-001', 'BoomBox Portable', 'Portable Bluetooth speaker with 360° sound, 24-hour battery life, IPX7 waterproof rating, built-in power bank, and party mode for multi-speaker pairing.', 129.99, 'EUR', 'speaker,bluetooth,portable,waterproof,party', 80, 'Audio'),

('TABLET-PRO-001', 'TabletPro 11"', '11-inch tablet with AMOLED display, Snapdragon 8 Gen 2 processor, 8GB RAM, 256GB storage, S-Pen support, and 5G connectivity.', 799.99, 'EUR', 'tablet,amoled,5g,stylus,portable', 35, 'Electronics'),

('CHARGER-USB-001', 'PowerHub 100W', '100W USB-C GaN charger with 4 ports (2x USB-C, 2x USB-A), fast charging support for laptops, tablets, and phones. Compact and travel-friendly.', 79.99, 'EUR', 'charger,usb-c,gan,fast-charging,travel', 200, 'Accessories'),

('WEBCAM-4K-001', 'StreamCam 4K', '4K webcam with auto-focus, noise-canceling dual microphones, privacy shutter, HDR support, and AI-powered background blur.', 199.99, 'EUR', 'webcam,4k,streaming,microphone,hdr', 45, 'Accessories'),

('DOCK-USB-001', 'UniversalDock Pro', 'USB-C docking station with dual 4K HDMI, Gigabit Ethernet, 3x USB-A, 2x USB-C, SD card reader, and 100W power delivery pass-through.', 249.99, 'EUR', 'dock,usb-c,hdmi,ethernet,professional', 30, 'Accessories');

-- ============================================================================
-- Stored Procedures for Vector Search
-- ============================================================================

-- Procedure for vector similarity search (requires VECTOR type support)
-- CREATE PROCEDURE sp_VectorSearchProducts
--     @QueryVector VECTOR(3072),
--     @TopK INT = 10
-- AS
-- BEGIN
--     SELECT TOP (@TopK)
--         sku, name, description, price, currency, tags, stock, category,
--         VECTOR_DISTANCE('cosine', @QueryVector, description_embedding) AS distance
--     FROM products
--     WHERE description_embedding IS NOT NULL
--     ORDER BY distance ASC
-- END;

PRINT 'Azure SQL Product Catalog schema created successfully!';
PRINT 'Products inserted: 12';
