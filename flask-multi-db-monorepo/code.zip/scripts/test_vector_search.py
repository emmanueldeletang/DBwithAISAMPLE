#!/usr/bin/env python3
"""Test vector search functionality with Azure SQL."""
import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()

from shared.config import azure_sql_config
from shared.embeddings import generate_embedding

def test_vector_search():
    """Test vector search using VECTOR_DISTANCE."""
    
    print("="*60)
    print("  Testing Azure SQL Vector Search")
    print("="*60)
    
    # Test query
    query = "wireless headphones with noise cancellation"
    print(f"\nSearch query: '{query}'")
    
    # Generate embedding for query
    print("\nGenerating query embedding...")
    query_embedding = generate_embedding(query)
    
    if not query_embedding:
        print("Failed to generate embedding!")
        return
    
    print(f"  ✓ Embedding generated ({len(query_embedding)} dimensions)")
    
    # Connect and search
    print("\nPerforming vector search...")
    conn = azure_sql_config.get_connection()
    cursor = conn.cursor()
    
    embedding_json = json.dumps(query_embedding)
    
    cursor.execute("""
        SELECT TOP (5)
            sku, name, description,
            VECTOR_DISTANCE('cosine', description_embedding, CAST(? AS VECTOR(1536))) AS distance
        FROM products
        WHERE description_embedding IS NOT NULL
        ORDER BY distance ASC
    """, (embedding_json,))
    
    print("\n" + "="*60)
    print("  Vector Search Results (Top 5)")
    print("="*60)
    
    for i, row in enumerate(cursor.fetchall(), 1):
        sku, name, description, distance = row
        similarity = 1 - distance
        print(f"\n{i}. {name} (SKU: {sku})")
        print(f"   Similarity: {similarity:.4f}")
        print(f"   Description: {description[:80]}...")
    
    cursor.close()
    conn.close()
    
    print("\n" + "="*60)
    print("  ✓ Vector search test complete!")
    print("="*60)


if __name__ == '__main__':
    test_vector_search()
