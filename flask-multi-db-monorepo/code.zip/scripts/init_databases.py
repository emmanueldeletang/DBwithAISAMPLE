#!/usr/bin/env python3
"""
Database Initialization Script
Creates schemas, tables, and sample data for all three databases:
- PostgreSQL (Orders)
- MongoDB vCore (Logistics)
- Azure SQL (Products) - Optional, as it may require specific permissions

Run this script after setting up your .env file with database credentials.
"""
import os
import sys
import uuid
import random
from datetime import datetime, timedelta
from dotenv import load_dotenv


# Add parent directory for shared imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()

# ============================================================================
# Shared Data (used across all databases)
# ============================================================================

# Customer data (shared between PostgreSQL and MongoDB)
CUSTOMERS_DATA = [
    ('Jean', 'Dupont', 'jean.dupont@email.fr', '+33 6 12 34 56 78', '15 Rue de la Paix', 'Paris', 'France', '75001'),
    ('Marie', 'Martin', 'marie.martin@email.fr', '+33 6 23 45 67 89', '28 Avenue des Champs-Élysées', 'Paris', 'France', '75008'),
    ('Pierre', 'Bernard', 'pierre.bernard@email.fr', '+33 6 34 56 78 90', '42 Rue de la République', 'Lyon', 'France', '69001'),
    ('Sophie', 'Petit', 'sophie.petit@email.fr', '+33 6 45 67 89 01', '7 Place Bellecour', 'Lyon', 'France', '69002'),
    ('Lucas', 'Robert', 'lucas.robert@email.fr', '+33 6 56 78 90 12', '33 Quai des Belges', 'Marseille', 'France', '13001'),
    ('Emma', 'Richard', 'emma.richard@email.fr', '+33 6 67 89 01 23', '12 Rue Sainte-Catherine', 'Bordeaux', 'France', '33000'),
    ('Louis', 'Durand', 'louis.durand@email.fr', '+33 6 78 90 12 34', '56 Place du Capitole', 'Toulouse', 'France', '31000'),
    ('Léa', 'Leroy', 'lea.leroy@email.fr', '+33 6 89 01 23 45', '89 Rue de la Liberté', 'Lille', 'France', '59000'),
    ('Hugo', 'Moreau', 'hugo.moreau@email.fr', '+33 6 90 12 34 56', '23 Avenue Jean Jaurès', 'Nantes', 'France', '44000'),
    ('Chloé', 'Simon', 'chloe.simon@email.fr', '+33 6 01 23 45 67', '67 Rue du Vieux Port', 'Nice', 'France', '06000'),
    ('Thomas', 'Laurent', 'thomas.laurent@email.fr', '+33 6 11 22 33 44', '45 Boulevard Haussmann', 'Paris', 'France', '75009'),
    ('Camille', 'Michel', 'camille.michel@email.fr', '+33 6 22 33 44 55', '78 Rue de Rivoli', 'Paris', 'France', '75004'),
]

# Products data (shared between Azure SQL and PostgreSQL orders)
PRODUCTS_DATA = [
    ('LAPTOP-PRO-001', 'ProBook Laptop 15"', 'Professional laptop with 15.6" Full HD display, Intel Core i7 processor, 16GB RAM, 512GB SSD. Perfect for business and productivity.', 1299.99, 'laptop,professional,business,intel,portable', 50, 'Computers'),
    ('LAPTOP-GAMING-001', 'GameMaster X17', 'High-performance gaming laptop with 17.3" 144Hz display, RTX 4070 graphics, 32GB RAM, 1TB NVMe SSD.', 2199.99, 'laptop,gaming,rtx,high-performance,rgb', 25, 'Gaming'),
    ('HEADPHONES-WL-001', 'SoundWave Pro Wireless', 'Premium wireless over-ear headphones with active noise cancellation, 40-hour battery life, Bluetooth 5.3.', 299.99, 'headphones,wireless,anc,bluetooth,audio', 100, 'Audio'),
    ('HEADPHONES-GAMING-001', 'ProGamer Headset 7.1', 'Professional gaming headset with 7.1 surround sound, detachable microphone, RGB lighting.', 149.99, 'headphones,gaming,7.1,surround,rgb,microphone', 75, 'Gaming'),
    ('KEYBOARD-MECH-001', 'MechType Elite', 'Mechanical gaming keyboard with Cherry MX Brown switches, per-key RGB lighting, aluminum frame.', 179.99, 'keyboard,mechanical,gaming,rgb,cherry-mx', 60, 'Gaming'),
    ('MOUSE-GAMING-001', 'PrecisionX Gaming Mouse', 'High-precision gaming mouse with 25,000 DPI optical sensor, 8 programmable buttons.', 89.99, 'mouse,gaming,rgb,precision,lightweight', 120, 'Gaming'),
    ('MONITOR-4K-001', 'UltraView 27" 4K', '27-inch 4K UHD IPS monitor with HDR400, 99% sRGB coverage, USB-C with 65W power delivery.', 549.99, 'monitor,4k,uhd,hdr,usb-c,professional', 40, 'Computers'),
    ('SPEAKER-BT-001', 'BoomBox Portable', 'Portable Bluetooth speaker with 360° sound, 24-hour battery life, IPX7 waterproof rating.', 129.99, 'speaker,bluetooth,portable,waterproof,party', 80, 'Audio'),
    ('TABLET-PRO-001', 'TabletPro 11"', '11-inch tablet with AMOLED display, Snapdragon 8 Gen 2 processor, 8GB RAM, 256GB storage.', 799.99, 'tablet,amoled,5g,stylus,portable', 35, 'Electronics'),
    ('CHARGER-USB-001', 'PowerHub 100W', '100W USB-C GaN charger with 4 ports (2x USB-C, 2x USB-A), fast charging support.', 79.99, 'charger,usb-c,gan,fast-charging,travel', 200, 'Accessories'),
    ('WEBCAM-4K-001', 'StreamCam 4K', '4K webcam with auto-focus, noise-canceling dual microphones, privacy shutter, HDR support.', 199.99, 'webcam,4k,streaming,microphone,hdr', 45, 'Accessories'),
    ('DOCK-USB-001', 'UniversalDock Pro', 'USB-C docking station with dual 4K HDMI, Gigabit Ethernet, 3x USB-A, 2x USB-C, SD card reader.', 249.99, 'dock,usb-c,hdmi,ethernet,professional', 30, 'Accessories'),
    ('EARBUDS-001', 'AirSound Pro', 'True wireless earbuds with ANC, 30-hour battery life, wireless charging case, IPX5 rating.', 179.99, 'earbuds,wireless,anc,bluetooth,waterproof', 150, 'Audio'),
    ('SMARTWATCH-001', 'FitPro Watch', 'Smartwatch with AMOLED display, heart rate monitor, GPS, 7-day battery life, water resistant.', 299.99, 'smartwatch,fitness,gps,health,waterproof', 65, 'Electronics'),
    ('SSD-001', 'SpeedDrive 2TB', '2TB NVMe SSD with 7000MB/s read speed, PCIe 4.0, heatsink included.', 199.99, 'ssd,nvme,storage,fast,pcie4', 90, 'Computers'),
]

# Store created orders for MongoDB to reference (populated by PostgreSQL setup)
CREATED_ORDERS = []

# ============================================================================
# PostgreSQL Setup (with Azure AI and Vector Extensions)
# ============================================================================

def setup_postgresql():
    """Create PostgreSQL schema and sample data with Azure AI vector embeddings."""
    import psycopg2
    from psycopg2.extras import RealDictCursor
    
    print("\n" + "="*60)
    print("  PostgreSQL Database Setup (with Azure AI Extensions)")
    print("="*60)
    
    host = os.getenv('POSTGRES_HOST', 'localhost')
    port = os.getenv('POSTGRES_PORT', '5432')
    database = os.getenv('POSTGRES_DATABASE', 'ordersdb')
    user = os.getenv('POSTGRES_USER', 'postgres')
    password = os.getenv('POSTGRES_PASSWORD', '')
    
    # Azure OpenAI settings for azure_ai extension
    openai_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT', '')
    openai_key = os.getenv('AZURE_OPENAI_API_KEY', '')
    embedding_deployment = os.getenv('AZURE_OPENAI_EMBEDDING_DEPLOYMENT', 'text-embedding-3-large')
    embedding_dimension = os.getenv('AZURE_OPENAI_EMBEDDING_DIMENSION', '1536')
    
    print(f"Connecting to PostgreSQL: {host}:{port}/{database}")
    
    try:
        conn = psycopg2.connect(
            host=host,
            port=int(port),
            database=database,
            user=user,
            password=password,
            sslmode='require'
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        print("✓ Connected successfully!")
        
        # ================================================================
        # Enable Extensions (azure_ai, vector, pg_trgm)
        # ================================================================
        print("\nEnabling extensions...")
        
        # Enable azure_ai extension for OpenAI embeddings
        azure_ai_enabled = False
        try:
            cursor.execute('CREATE EXTENSION IF NOT EXISTS "azure_ai";')
            print("  ✓ Extension azure_ai enabled")
            azure_ai_enabled = True
        except Exception as e:
            print(f"  ⚠ Extension azure_ai: {e}")
        
        # Enable vector extension for vector operations
        vector_enabled = False
        try:
            cursor.execute('CREATE EXTENSION IF NOT EXISTS "vector";')
            print("  ✓ Extension vector enabled")
            vector_enabled = True
        except Exception as e:
            print(f"  ⚠ Extension vector: {e}")
        
        # Enable pg_diskann extension for DiskANN index (high-performance ANN search)
        diskann_enabled = False
        try:
            cursor.execute('CREATE EXTENSION IF NOT EXISTS "pg_diskann" CASCADE;')
            print("  ✓ Extension pg_diskann enabled (DiskANN index support)")
            diskann_enabled = True
        except Exception as e:
            print(f"  ⚠ Extension pg_diskann: {e}")
        
        # Try pg_trgm for text search
        try:
            cursor.execute('CREATE EXTENSION IF NOT EXISTS "pg_trgm";')
            print("  ✓ Extension pg_trgm enabled")
        except Exception as e:
            print(f"  ⚠ Extension pg_trgm: {e}")
        
        # Try uuid-ossp extension
        uuid_func = "gen_random_uuid()"  # Built-in since PostgreSQL 13
        try:
            cursor.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp";')
            print("  ✓ Extension uuid-ossp enabled")
            uuid_func = "uuid_generate_v4()"
        except Exception as e:
            print(f"  ⚠ Extension uuid-ossp not available, using gen_random_uuid()")
        
        # ================================================================
        # Configure Azure OpenAI in azure_ai extension
        # ================================================================
        if azure_ai_enabled and openai_endpoint and openai_key:
            print("\nConfiguring Azure OpenAI in azure_ai extension...")
            try:
                cursor.execute("SELECT azure_ai.set_setting('azure_openai.endpoint', %s);", (openai_endpoint,))
                cursor.execute("SELECT azure_ai.set_setting('azure_openai.subscription_key', %s);", (openai_key,))
                print(f"  ✓ Azure OpenAI endpoint configured: {openai_endpoint[:50]}...")
                print(f"  ✓ Embedding deployment: {embedding_deployment}")
            except Exception as e:
                print(f"  ⚠ Failed to configure Azure OpenAI: {e}")
                azure_ai_enabled = False
        
        # ================================================================
        # Drop existing tables
        # ================================================================
        print("\nDropping existing tables...")
        cursor.execute("DROP TABLE IF EXISTS order_items CASCADE;")
        cursor.execute("DROP TABLE IF EXISTS orders CASCADE;")
        cursor.execute("DROP TABLE IF EXISTS customers CASCADE;")
        print("  ✓ Tables dropped")
        
        # ================================================================
        # Create tables
        # ================================================================
        print("\nCreating tables...")
        
        # Create customers table (without vector column initially)
        cursor.execute(f"""
            CREATE TABLE customers (
                customer_id UUID PRIMARY KEY DEFAULT {uuid_func},
                first_name VARCHAR(100) NOT NULL,
                last_name VARCHAR(100) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                phone VARCHAR(50),
                address TEXT,
                city VARCHAR(100),
                country VARCHAR(100),
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
            );
        """)
        print("  ✓ Table 'customers' created")
        
        # Add vector column using ALTER TABLE with GENERATED ALWAYS
        # This automatically generates embeddings using azure_openai.create_embeddings()
        # Note: text-embedding-3-large returns 3072 dimensions by default in azure_ai extension
        if azure_ai_enabled and vector_enabled:
            try:
                # Use 3072 dimensions for text-embedding-3-large (azure_ai extension default)
                # or use text-embedding-ada-002 for 1536 dimensions
                cursor.execute(f"""
                    ALTER TABLE customers 
                    ADD COLUMN name_embedding vector(3072)
                    GENERATED ALWAYS AS (
                        azure_openai.create_embeddings('{embedding_deployment}', 
                            first_name || ' ' || last_name || ' ' || COALESCE(city, '') || ' ' || COALESCE(country, '')
                        )::vector
                    ) STORED;
                """)
                print(f"  ✓ Added name_embedding column (vector(3072)) with auto-generation")
            except Exception as e:
                print(f"  ⚠ Could not add generated vector column: {e}")
        
        # Create orders table
        cursor.execute(f"""
            CREATE TABLE orders (
                order_id UUID PRIMARY KEY DEFAULT {uuid_func},
                customer_id UUID NOT NULL REFERENCES customers(customer_id) ON DELETE CASCADE,
                order_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled')),
                total_amount DECIMAL(12, 2) NOT NULL DEFAULT 0,
                currency VARCHAR(3) DEFAULT 'EUR',
                notes TEXT,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
            );
        """)
        print("  ✓ Table 'orders' created")
        
        # Add vector column for order notes
        if azure_ai_enabled and vector_enabled:
            try:
                cursor.execute(f"""
                    ALTER TABLE orders 
                    ADD COLUMN notes_embedding vector(3072)
                    GENERATED ALWAYS AS (
                        CASE WHEN notes IS NOT NULL AND notes != '' 
                        THEN azure_openai.create_embeddings('{embedding_deployment}', notes)::vector
                        ELSE NULL END
                    ) STORED;
                """)
                print(f"  ✓ Added notes_embedding column to orders (vector(3072))")
            except Exception as e:
                print(f"  ⚠ Could not add notes_embedding column: {e}")
        
        # Create order_items table with category
        cursor.execute(f"""
            CREATE TABLE order_items (
                order_item_id UUID PRIMARY KEY DEFAULT {uuid_func},
                order_id UUID NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
                product_sku VARCHAR(50) NOT NULL,
                product_name VARCHAR(200) NOT NULL,
                category VARCHAR(100),
                quantity INT NOT NULL CHECK (quantity > 0),
                unit_price DECIMAL(10, 2) NOT NULL,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
            );
        """)
        print("  ✓ Table 'order_items' created")
        
        # ================================================================
        # Create indexes (including HNSW vector index)
        # ================================================================
        print("\nCreating indexes...")
        indexes = [
            "CREATE INDEX idx_customers_email ON customers(email);",
            "CREATE INDEX idx_customers_city ON customers(city);",
            "CREATE INDEX idx_customers_country ON customers(country);",
            "CREATE INDEX idx_orders_customer_id ON orders(customer_id);",
            "CREATE INDEX idx_orders_status ON orders(status);",
            "CREATE INDEX idx_orders_order_date ON orders(order_date DESC);",
            "CREATE INDEX idx_order_items_order_id ON order_items(order_id);",
            "CREATE INDEX idx_order_items_product_sku ON order_items(product_sku);",
            "CREATE INDEX idx_order_items_category ON order_items(category);",
        ]
        
        for idx in indexes:
            try:
                cursor.execute(idx)
            except Exception as e:
                print(f"  ⚠ Index error: {e}")
        
        # Create vector index for similarity search
        # Priority: DiskANN > HNSW > IVFFlat
        if azure_ai_enabled and vector_enabled:
            index_created = False
            
            # Try DiskANN first (best performance for high-dimensional vectors)
            if diskann_enabled and not index_created:
                try:
                    cursor.execute("""
                        CREATE INDEX idx_customers_name_embedding_diskann 
                        ON customers USING diskann (name_embedding vector_cosine_ops);
                    """)
                    print("  ✓ DiskANN vector index created on customers.name_embedding")
                    index_created = True
                except Exception as e:
                    print(f"  ⚠ DiskANN index failed: {e}")
            
            # Try HNSW (fast but limited to 2000 dimensions)
            if not index_created:
                try:
                    cursor.execute("""
                        CREATE INDEX idx_customers_name_embedding_hnsw 
                        ON customers USING hnsw (name_embedding vector_cosine_ops)
                        WITH (m = 16, ef_construction = 64);
                    """)
                    print("  ✓ HNSW vector index created on customers.name_embedding")
                    index_created = True
                except Exception as e:
                    print(f"  ⚠ HNSW index failed: {e}")
            
            # Fall back to IVFFlat for higher dimensions
            if not index_created:
                try:
                    cursor.execute("""
                        CREATE INDEX idx_customers_name_embedding_ivfflat 
                        ON customers USING ivfflat (name_embedding vector_cosine_ops)
                        WITH (lists = 100);
                    """)
                    print("  ✓ IVFFlat vector index created on customers.name_embedding")
                    index_created = True
                except Exception as e2:
                    print(f"  ⚠ Could not create vector index: {e2}")
        
        print("  ✓ Indexes created")
        
        # Insert sample customers (using shared data)
        print("\nInserting sample data...")
        
        customer_ids = []
        for c in CUSTOMERS_DATA:
            first_name, last_name, email, phone, address, city, country, postal = c
            cursor.execute("""
                INSERT INTO customers (first_name, last_name, email, phone, address, city, country)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING customer_id
            """, (first_name, last_name, email, phone, address, city, country))
            customer_ids.append(cursor.fetchone()[0])
        
        print(f"  ✓ {len(CUSTOMERS_DATA)} customers inserted")
        
        # Sample products for orders (using shared data - sku, name, price, category)
        products = [(p[0], p[1], p[3], p[6]) for p in PRODUCTS_DATA]
        
        statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered']
        order_count = 0
        item_count = 0
        
        # Clear previously created orders
        CREATED_ORDERS.clear()
        
        # Create orders for each customer
        for idx, customer_id in enumerate(customer_ids):
            customer_data = CUSTOMERS_DATA[idx]
            customer_name = f"{customer_data[0]} {customer_data[1]}"
            
            # 1-3 orders per customer
            num_orders = random.randint(1, 3)
            for _ in range(num_orders):
                status = random.choice(statuses)
                order_date = datetime.now() - timedelta(days=random.randint(1, 90))
                
                # Calculate total from items
                num_items = random.randint(1, 4)
                selected_products = random.sample(products, min(num_items, len(products)))
                total = sum(p[2] * random.randint(1, 2) for p in selected_products)
                
                cursor.execute("""
                    INSERT INTO orders (customer_id, order_date, status, total_amount, currency)
                    VALUES (%s, %s, %s, %s, 'EUR')
                    RETURNING order_id
                """, (customer_id, order_date, status, total))
                order_id = cursor.fetchone()[0]
                order_count += 1
                
                # Store order info for MongoDB deliveries
                CREATED_ORDERS.append({
                    'order_id': str(order_id),
                    'customer_name': customer_name,
                    'customer_address': customer_data[4],
                    'customer_city': customer_data[5],
                    'customer_country': customer_data[6],
                    'customer_postal': customer_data[7],
                    'status': status,
                    'order_date': order_date,
                    'total_amount': float(total)
                })
                
                # Insert order items with category
                for product in selected_products:
                    quantity = random.randint(1, 2)
                    cursor.execute("""
                        INSERT INTO order_items (order_id, product_sku, product_name, quantity, unit_price, category)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (order_id, product[0], product[1], quantity, product[2], product[3]))
                    item_count += 1
        
        print(f"  ✓ {order_count} orders inserted")
        print(f"  ✓ {item_count} order items inserted")
        
        # Create update trigger function
        cursor.execute("""
            CREATE OR REPLACE FUNCTION update_updated_at_column()
            RETURNS TRIGGER AS $$
            BEGIN
                NEW.updated_at = CURRENT_TIMESTAMP;
                RETURN NEW;
            END;
            $$ language 'plpgsql';
        """)
        
        cursor.execute("""
            DROP TRIGGER IF EXISTS update_customers_updated_at ON customers;
            CREATE TRIGGER update_customers_updated_at
                BEFORE UPDATE ON customers
                FOR EACH ROW
                EXECUTE FUNCTION update_updated_at_column();
        """)
        
        cursor.execute("""
            DROP TRIGGER IF EXISTS update_orders_updated_at ON orders;
            CREATE TRIGGER update_orders_updated_at
                BEFORE UPDATE ON orders
                FOR EACH ROW
                EXECUTE FUNCTION update_updated_at_column();
        """)
        print("  ✓ Triggers created")
        
        cursor.close()
        conn.close()
        
        print("\n✅ PostgreSQL setup complete!")
        return True
        
    except Exception as e:
        print(f"\n❌ PostgreSQL setup failed: {e}")
        return False


# ============================================================================
# MongoDB Setup
# ============================================================================

def setup_mongodb():
    """Create MongoDB collections and sample data."""
    from pymongo import MongoClient
    from pymongo.errors import CollectionInvalid
    
    print("\n" + "="*60)
    print("  MongoDB Database Setup")
    print("="*60)
    
    host = os.getenv('MONGODB_HOST', 'localhost')
    user = os.getenv('MONGODB_USER', '')
    password = os.getenv('MONGODB_PASSWORD', '')
    database = os.getenv('MONGODB_DATABASE', 'logisticsdb')
    
    # Build connection string
    if user and password:
        connection_string = f"mongodb+srv://{user}:{password}@{host}/?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000"
    else:
        connection_string = f"mongodb://{host}:27017/"
    
    print(f"Connecting to MongoDB: {host}/{database}")
    
    try:
        client = MongoClient(connection_string)
        db = client[database]
        
        # Test connection
        client.admin.command('ping')
        print("✓ Connected successfully!")
        
        # Drop existing collections
        print("\nDropping existing collections...")
        try:
            db.drop_collection('partners')
            db.drop_collection('deliveries')
        except:
            pass
        print("  ✓ Collections dropped")
        
        # Create partners collection
        print("\nCreating collections...")
        partners = db.create_collection('partners')
        print("  ✓ Collection 'partners' created")
        
        # Create deliveries collection
        deliveries = db.create_collection('deliveries')
        print("  ✓ Collection 'deliveries' created")
        
        # Create indexes
        print("\nCreating indexes...")
        partners.create_index('partner_id', unique=True)
        partners.create_index('name')
        partners.create_index('active')
        partners.create_index('service_areas')
        
        deliveries.create_index('delivery_id', unique=True)
        deliveries.create_index('tracking_number', unique=True)
        deliveries.create_index('order_id')
        deliveries.create_index('partner_id')
        deliveries.create_index('status')
        deliveries.create_index([('created_at', -1)])
        deliveries.create_index('address.city')
        
        # Text search index
        deliveries.create_index([
            ('customer_name', 'text'),
            ('status_text', 'text'),
            ('notes', 'text'),
            ('address.street', 'text'),
            ('address.city', 'text')
        ], name='deliveries_text_idx')
        
        print("  ✓ Indexes created")
        
        # Insert sample partners
        print("\nInserting sample data...")
        now = datetime.utcnow()
        
        partners_data = [
            {
                'partner_id': 'PART001',
                'name': 'SpeedyExpress',
                'contact_email': 'contact@speedyexpress.fr',
                'contact_phone': '+33 1 23 45 67 89',
                'service_areas': ['Paris', 'Lyon', 'Marseille', 'Bordeaux', 'Toulouse'],
                'vehicle_types': ['Van', 'Truck', 'Bike'],
                'active': True,
                'created_at': now,
                'updated_at': now
            },
            {
                'partner_id': 'PART002',
                'name': 'EcoLivraison',
                'contact_email': 'hello@ecolivraison.fr',
                'contact_phone': '+33 1 34 56 78 90',
                'service_areas': ['Paris', 'Lille', 'Nantes', 'Nice'],
                'vehicle_types': ['Electric Van', 'Cargo Bike'],
                'active': True,
                'created_at': now,
                'updated_at': now
            },
            {
                'partner_id': 'PART003',
                'name': 'FlashDelivery',
                'contact_email': 'pro@flashdelivery.fr',
                'contact_phone': '+33 1 45 67 89 01',
                'service_areas': ['Lyon', 'Grenoble', 'Saint-Étienne'],
                'vehicle_types': ['Van', 'Scooter'],
                'active': True,
                'created_at': now,
                'updated_at': now
            },
            {
                'partner_id': 'PART004',
                'name': 'NightOwl Logistics',
                'contact_email': 'support@nightowl.fr',
                'contact_phone': '+33 1 56 78 90 12',
                'service_areas': ['Paris', 'Lyon', 'Marseille'],
                'vehicle_types': ['Truck', 'Van'],
                'active': False,
                'created_at': now,
                'updated_at': now
            },
            {
                'partner_id': 'PART005',
                'name': 'GreenWheels',
                'contact_email': 'info@greenwheels.fr',
                'contact_phone': '+33 1 67 89 01 23',
                'service_areas': ['Paris', 'Versailles', 'Fontainebleau'],
                'vehicle_types': ['Electric Van', 'Electric Bike'],
                'active': True,
                'created_at': now,
                'updated_at': now
            }
        ]
        
        partners.insert_many(partners_data)
        print(f"  ✓ {len(partners_data)} partners inserted")
        
        # Insert sample deliveries using orders from PostgreSQL
        # Map delivery statuses based on order statuses
        order_to_delivery_status = {
            'pending': 'pending',
            'confirmed': 'pending',
            'processing': 'picked_up',
            'shipped': 'in_transit',
            'delivered': 'delivered'
        }
        
        statuses = ['pending', 'picked_up', 'in_transit', 'out_for_delivery', 'delivered', 'failed']
        status_texts = {
            'pending': 'Awaiting pickup',
            'picked_up': 'Package picked up from warehouse',
            'in_transit': 'Package in transit to destination',
            'out_for_delivery': 'Out for delivery',
            'delivered': 'Package delivered successfully',
            'failed': 'Delivery attempt failed'
        }
        
        deliveries_data = []
        
        # Use orders created in PostgreSQL if available
        if CREATED_ORDERS:
            print(f"  Using {len(CREATED_ORDERS)} orders from PostgreSQL...")
            for i, order in enumerate(CREATED_ORDERS):
                # Map order status to delivery status
                base_status = order_to_delivery_status.get(order['status'], 'pending')
                # Randomly advance some to next status
                if base_status == 'in_transit' and random.random() > 0.5:
                    status = random.choice(['in_transit', 'out_for_delivery', 'delivered'])
                elif base_status == 'pending' and random.random() > 0.7:
                    status = 'picked_up'
                else:
                    status = base_status
                
                partner_id = random.choice(['PART001', 'PART002', 'PART003', 'PART005'])
                created = order['order_date'] if isinstance(order['order_date'], datetime) else now - timedelta(days=random.randint(1, 30))
                
                # Build event history
                events = [{'timestamp': created, 'status': 'pending', 'description': 'Order received', 'location': ''}]
                
                if status != 'pending':
                    events.append({'timestamp': created + timedelta(hours=2), 'status': 'picked_up', 'description': 'Package picked up', 'location': f"{order['customer_city']} Hub"})
                if status in ['in_transit', 'out_for_delivery', 'delivered', 'failed']:
                    events.append({'timestamp': created + timedelta(hours=12), 'status': 'in_transit', 'description': 'In transit', 'location': ''})
                if status in ['out_for_delivery', 'delivered', 'failed']:
                    events.append({'timestamp': created + timedelta(hours=24), 'status': 'out_for_delivery', 'description': 'Out for delivery', 'location': order['customer_city']})
                if status == 'delivered':
                    events.append({'timestamp': created + timedelta(hours=26), 'status': 'delivered', 'description': 'Delivered to recipient', 'location': order['customer_city']})
                if status == 'failed':
                    events.append({'timestamp': created + timedelta(hours=26), 'status': 'failed', 'description': 'No one home', 'location': order['customer_city']})
                
                delivery = {
                    'delivery_id': f'DEL{str(i+1).zfill(3)}',
                    'tracking_number': f'TRK{uuid.uuid4().hex[:10].upper()}',
                    'order_id': order['order_id'],  # Real PostgreSQL order UUID
                    'customer_name': order['customer_name'],  # Real customer name
                    'partner_id': partner_id,
                    'status': status,
                    'status_text': status_texts[status],
                    'address': {
                        'street': order['customer_address'],
                        'city': order['customer_city'],
                        'postal_code': order['customer_postal'],
                        'country': order['customer_country']
                    },
                    'notes': random.choice(['', 'Leave at door', 'Call before delivery', 'Fragile items']),
                    'eta': created + timedelta(days=2) if status not in ['delivered', 'failed'] else None,
                    'events': events,
                    'created_at': created,
                    'updated_at': now,
                    'last_update': now
                }
                deliveries_data.append(delivery)
        else:
            # Fallback: use shared customer data if PostgreSQL wasn't run first
            print("  No PostgreSQL orders found, using shared customer data...")
            for i, customer in enumerate(CUSTOMERS_DATA[:8]):
                first_name, last_name, email, phone, address, city, country, postal = customer
                name = f"{first_name} {last_name}"
                status = random.choice(statuses)
                partner_id = random.choice(['PART001', 'PART002', 'PART003', 'PART005'])
                
                created = now - timedelta(days=random.randint(1, 30))
                
                # Build event history
                events = [{'timestamp': created, 'status': 'pending', 'description': 'Order received', 'location': ''}]
                
                if status != 'pending':
                    events.append({'timestamp': created + timedelta(hours=2), 'status': 'picked_up', 'description': 'Package picked up', 'location': f'{city} Hub'})
                if status in ['in_transit', 'out_for_delivery', 'delivered', 'failed']:
                    events.append({'timestamp': created + timedelta(hours=12), 'status': 'in_transit', 'description': 'In transit', 'location': ''})
                if status in ['out_for_delivery', 'delivered', 'failed']:
                    events.append({'timestamp': created + timedelta(hours=24), 'status': 'out_for_delivery', 'description': 'Out for delivery', 'location': city})
                if status == 'delivered':
                    events.append({'timestamp': created + timedelta(hours=26), 'status': 'delivered', 'description': 'Delivered to recipient', 'location': city})
                if status == 'failed':
                    events.append({'timestamp': created + timedelta(hours=26), 'status': 'failed', 'description': 'No one home', 'location': city})
                
                delivery = {
                    'delivery_id': f'DEL{str(i+1).zfill(3)}',
                    'tracking_number': f'TRK{uuid.uuid4().hex[:10].upper()}',
                    'order_id': f'ORD-2026-{str(i+1).zfill(3)}',
                    'customer_name': name,
                    'partner_id': partner_id,
                    'status': status,
                    'status_text': status_texts[status],
                    'address': {
                        'street': address,
                        'city': city,
                        'postal_code': postal,
                        'country': country
                    },
                    'notes': random.choice(['', 'Leave at door', 'Call before delivery', 'Fragile items']),
                    'eta': created + timedelta(days=2) if status not in ['delivered', 'failed'] else None,
                    'events': events,
                    'created_at': created,
                    'updated_at': now,
                    'last_update': now
                }
                deliveries_data.append(delivery)
        
        deliveries.insert_many(deliveries_data)
        print(f"  ✓ {len(deliveries_data)} deliveries inserted")
        
        client.close()
        
        print("\n✅ MongoDB setup complete!")
        return True
        
    except Exception as e:
        print(f"\n❌ MongoDB setup failed: {e}")
        import traceback
        traceback.print_exc()
        return False


# ============================================================================
# Azure SQL Setup (uses mssql-python driver)
# ============================================================================

def setup_azure_sql():
    """Create Azure SQL schema and sample data using mssql-python driver with vector embeddings."""
    from mssql_python import connect
    import json
    
    # Import shared embeddings module
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from shared.embeddings import generate_embedding
    
    print("\n" + "="*60)
    print("  Azure SQL Database Setup (with Vector Embeddings)")
    print("="*60)
    
    # Build connection string from environment variables
    server = os.getenv('AZURE_SQL_SERVER', 'edesa.database.windows.net')
    database = os.getenv('AZURE_SQL_DATABASE', 'emedelsql')
    
    if not server:
        print("⚠ AZURE_SQL_SERVER not configured, skipping Azure SQL setup")
        return False
    
    # Connection string for Azure SQL with ActiveDirectoryInteractive authentication
    connection_string = os.getenv(
        'SQL_CONNECTION_STRING',
        f"Server={server};Database={database};Encrypt=yes;TrustServerCertificate=no;Authentication=ActiveDirectoryInteractive"
    )
    
    print(f"Connecting to Azure SQL: {server}/{database}")
    print("Using mssql-python driver with ActiveDirectoryInteractive authentication...")
    print("A browser window may open for authentication. Please complete the sign-in.")
    
    try:
        # Connect using mssql-python driver
        conn = connect(connection_string)
        cursor = conn.cursor()
        print("✓ Connected successfully!")
        
        # Drop existing tables
        print("\nDropping existing tables...")
        cursor.execute("IF OBJECT_ID('products', 'U') IS NOT NULL DROP TABLE products;")
        cursor.execute("IF OBJECT_ID('categories', 'U') IS NOT NULL DROP TABLE categories;")
        conn.commit()
        print("  ✓ Tables dropped")
        
        # Create categories table
        print("\nCreating tables...")
        cursor.execute("""
            CREATE TABLE categories (
                category_id INT IDENTITY(1,1) PRIMARY KEY,
                name NVARCHAR(100) NOT NULL,
                description NVARCHAR(500),
                parent_category_id INT NULL,
                created_at DATETIME2 DEFAULT GETUTCDATE()
            );
        """)
        conn.commit()
        print("  ✓ Table 'categories' created")
        
        # Create products table with VECTOR(1536) for OpenAI text-embedding-3-large
        # Note: Azure SQL supports max 1998 dimensions, using 1536 for compatibility
        cursor.execute("""
            CREATE TABLE products (
                sku NVARCHAR(50) PRIMARY KEY,
                name NVARCHAR(200) NOT NULL,
                description NVARCHAR(MAX),
                price DECIMAL(10, 2) NOT NULL,
                currency NVARCHAR(3) DEFAULT 'EUR',
                tags NVARCHAR(500),
                stock INT DEFAULT 0,
                category NVARCHAR(100),
                category_id INT NULL,
                description_embedding VECTOR(1536),
                created_at DATETIME2 DEFAULT GETUTCDATE(),
                updated_at DATETIME2 DEFAULT GETUTCDATE()
            );
        """)
        conn.commit()
        print("  ✓ Table 'products' created (with VECTOR(1536) for embeddings)")
        
        # Create indexes
        print("\nCreating indexes...")
        cursor.execute("CREATE INDEX IX_products_category ON products(category);")
        cursor.execute("CREATE INDEX IX_products_price ON products(price);")
        cursor.execute("CREATE INDEX IX_products_stock ON products(stock);")
        conn.commit()
        print("  ✓ Indexes created")
        
        # Insert categories
        print("\nInserting sample data...")
        categories = [
            ('Electronics', 'Electronic devices and accessories'),
            ('Computers', 'Laptops, desktops, and computer accessories'),
            ('Audio', 'Headphones, speakers, and audio equipment'),
            ('Gaming', 'Gaming consoles, accessories, and games'),
            ('Accessories', 'Various tech accessories'),
        ]
        
        for name, desc in categories:
            cursor.execute("INSERT INTO categories (name, description) VALUES (?, ?)", (name, desc))
        conn.commit()
        print(f"  ✓ {len(categories)} categories inserted")
        
        # Insert products with embeddings (using shared data)
        print("  Generating embeddings using Azure OpenAI...")
        products_inserted = 0
        embeddings_generated = 0
        
        for p in PRODUCTS_DATA:
            sku, name, description, price, tags, stock, category = p
            
            # Generate embedding for description using OpenAI
            embedding = generate_embedding(f"{name}. {description}")
            
            if embedding:
                # Convert embedding to JSON array format for VECTOR type
                embedding_json = json.dumps(embedding)
                cursor.execute("""
                    INSERT INTO products (sku, name, description, price, tags, stock, category, description_embedding)
                    VALUES (?, ?, ?, ?, ?, ?, ?, CAST(? AS VECTOR(1536)))
                """, (sku, name, description, price, tags, stock, category, embedding_json))
                embeddings_generated += 1
            else:
                # Insert without embedding if OpenAI is not available
                cursor.execute("""
                    INSERT INTO products (sku, name, description, price, tags, stock, category)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (sku, name, description, price, tags, stock, category))
            
            products_inserted += 1
        
        conn.commit()
        print(f"  ✓ {products_inserted} products inserted")
        print(f"  ✓ {embeddings_generated} embeddings generated and stored")
        
        cursor.close()
        conn.close()
        
        print("\n✅ Azure SQL setup complete!")
        return True
        
    except Exception as e:
        print(f"\n❌ Azure SQL setup failed: {e}")
        import traceback
        traceback.print_exc()
        return False


# ============================================================================
# Main
# ============================================================================

def main():
    """Run all database setups."""
    print("\n" + "="*60)
    print("  🚀 Multi-Database Initialization Script")
    print("="*60)
    print("\nThis script will create schemas and sample data for:")
    print("  • PostgreSQL (Orders database)")
    print("  • MongoDB (Logistics database)")
    print("  • Azure SQL (Products database)")
    print("\nMake sure your .env file is configured with database credentials.")
    print("="*60)
    
    results = {}
    
    # PostgreSQL
    try:
        results['PostgreSQL'] = setup_postgresql()
    except ImportError:
        print("\n⚠ psycopg2 not installed. Run: pip install psycopg2-binary")
        results['PostgreSQL'] = False
    
    # MongoDB
    try:
        results['MongoDB'] = setup_mongodb()
    except ImportError:
        print("\n⚠ pymongo not installed. Run: pip install pymongo")
        results['MongoDB'] = False
    
    # Azure SQL (using mssql-python driver)
    try:
        results['Azure SQL'] = setup_azure_sql()
    except ImportError:
        print("\n⚠ mssql-python not installed. Run: pip install mssql-python")
        results['Azure SQL'] = False
    
    # Summary
    print("\n" + "="*60)
    print("  📊 Setup Summary")
    print("="*60)
    for db, success in results.items():
        status = "✅ Success" if success else "❌ Failed"
        print(f"  {db}: {status}")
    print("="*60)
    
    all_success = all(results.values())
    if all_success:
        print("\n🎉 All databases initialized successfully!")
    else:
        print("\n⚠ Some databases failed to initialize. Check the logs above.")
    
    return 0 if all_success else 1


if __name__ == '__main__':
    sys.exit(main())
