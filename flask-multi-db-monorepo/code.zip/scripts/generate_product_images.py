#!/usr/bin/env python3
"""
Product Image Generation Script
Generates images for products using Azure OpenAI DALL-E,
uploads to Azure Blob Storage, and updates the database.

Prerequisites:
- Azure OpenAI with DALL-E 3 deployment
- Azure Blob Storage account with a container
- Azure SQL Database with products table

Usage:
    python generate_product_images.py [--limit N] [--dry-run]
"""
import os
import sys
import argparse
import time
from io import BytesIO
from datetime import datetime, timedelta
from dotenv import load_dotenv

# Add parent directory for shared imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()


def add_image_url_column():
    """Add image_url column to products table if it doesn't exist."""
    from mssql_python import connect
    
    connection_string = (
        f"Server={os.getenv('AZURE_SQL_SERVER')};"
        f"Database={os.getenv('AZURE_SQL_DATABASE', 'productcatalog')};"
        f"Encrypt=yes;TrustServerCertificate=no;"
        f"Authentication=ActiveDirectoryInteractive"
    )
    
    print("Adding image_url column to products table...")
    
    with connect(connection_string) as conn:
        cursor = conn.cursor()
        
        # Check if column exists
        cursor.execute("""
            SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME = 'products' AND COLUMN_NAME = 'image_url'
        """)
        
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                ALTER TABLE products 
                ADD image_url NVARCHAR(500) NULL
            """)
            conn.commit()
            print("✓ Added image_url column")
        else:
            print("✓ image_url column already exists")


def get_products_without_images():
    """Get all products that don't have an image URL."""
    from mssql_python import connect
    
    connection_string = (
        f"Server={os.getenv('AZURE_SQL_SERVER')};"
        f"Database={os.getenv('AZURE_SQL_DATABASE', 'productcatalog')};"
        f"Encrypt=yes;TrustServerCertificate=no;"
        f"Authentication=ActiveDirectoryInteractive"
    )
    
    products = []
    with connect(connection_string) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT sku, name, description, category 
            FROM products 
            WHERE image_url IS NULL OR image_url = ''
        """)
        
        columns = ['sku', 'name', 'description', 'category']
        for row in cursor.fetchall():
            products.append(dict(zip(columns, row)))
    
    return products


def get_all_products():
    """Get all products (for URL regeneration)."""
    from mssql_python import connect
    
    connection_string = (
        f"Server={os.getenv('AZURE_SQL_SERVER')};"
        f"Database={os.getenv('AZURE_SQL_DATABASE', 'productcatalog')};"
        f"Encrypt=yes;TrustServerCertificate=no;"
        f"Authentication=ActiveDirectoryInteractive"
    )
    
    products = []
    with connect(connection_string) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT sku, name, description, category 
            FROM products
        """)
        
        columns = ['sku', 'name', 'description', 'category']
        for row in cursor.fetchall():
            products.append(dict(zip(columns, row)))
    
    return products


def regenerate_sas_url(sku):
    """Regenerate SAS URL for an existing blob."""
    from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
    from datetime import datetime, timedelta
    
    connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
    container_name = os.getenv('AZURE_STORAGE_CONTAINER', 'product-images')
    account_name = os.getenv('AZURE_STORAGE_ACCOUNT')
    account_key = os.getenv('AZURE_STORAGE_KEY')
    
    if connection_string:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        for part in connection_string.split(';'):
            if part.startswith('AccountName='):
                account_name = part.split('=', 1)[1]
            elif part.startswith('AccountKey='):
                account_key = part.split('=', 1)[1]
    else:
        account_url = f"https://{account_name}.blob.core.windows.net"
        blob_service_client = BlobServiceClient(account_url, credential=account_key)
    
    blob_name = f"products/{sku.lower()}.png"
    container_client = blob_service_client.get_container_client(container_name)
    blob_client = container_client.get_blob_client(blob_name)
    
    # Check if blob exists
    if not blob_client.exists():
        return None
    
    # Generate new SAS token
    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.utcnow() + timedelta(days=3650)
    )
    
    return f"{blob_client.url}?{sas_token}"


def generate_image_prompt(product):
    """Create an effective prompt for DALL-E based on product details."""
    name = product['name']
    category = product.get('category', '')
    description = product.get('description', '')[:200]  # Limit description length
    
    # Create a product photography style prompt
    prompt = f"""Professional product photography of {name}. 
Category: {category}. 
Clean white background, studio lighting, high quality commercial product shot.
Modern minimalist style, centered composition, soft shadows.
{description[:100]}"""
    
    return prompt[:1000]  # DALL-E has prompt length limits


def generate_image_dalle(prompt):
    """Generate an image using Azure OpenAI DALL-E 3."""
    from openai import AzureOpenAI
    
    client = AzureOpenAI(
        azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
        api_key=os.getenv('AZURE_OPENAI_API_KEY'),
        api_version="2024-02-01"
    )
    
    # DALL-E deployment name (configure in your Azure OpenAI resource)
    dalle_deployment = os.getenv('AZURE_OPENAI_DALLE_DEPLOYMENT', 'dall-e-3')
    
    response = client.images.generate(
        model=dalle_deployment,
        prompt=prompt,
        size="1024x1024",
        quality="standard",
        n=1
    )
    
    # Get the image URL from the response
    image_url = response.data[0].url
    return image_url


def download_image(url):
    """Download image from URL and return bytes."""
    import requests
    
    response = requests.get(url, timeout=60)
    response.raise_for_status()
    return response.content


def upload_to_blob_storage(image_bytes, blob_name):
    """Upload image bytes to Azure Blob Storage."""
    from azure.storage.blob import BlobServiceClient, ContentSettings, generate_blob_sas, BlobSasPermissions
    from azure.core.exceptions import ResourceExistsError
    from datetime import datetime, timedelta
    
    # Get connection string or use account name + key
    connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
    container_name = os.getenv('AZURE_STORAGE_CONTAINER', 'product-images')
    account_name = os.getenv('AZURE_STORAGE_ACCOUNT')
    account_key = os.getenv('AZURE_STORAGE_KEY')
    
    if connection_string:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        # Extract account name and key from connection string for SAS generation
        for part in connection_string.split(';'):
            if part.startswith('AccountName='):
                account_name = part.split('=', 1)[1]
            elif part.startswith('AccountKey='):
                account_key = part.split('=', 1)[1]
    else:
        account_url = f"https://{account_name}.blob.core.windows.net"
        blob_service_client = BlobServiceClient(account_url, credential=account_key)
    
    # Get or create container
    container_client = blob_service_client.get_container_client(container_name)
    try:
        container_client.create_container(public_access='blob')
        print(f"  Created container: {container_name}")
    except ResourceExistsError:
        pass  # Container already exists
    except Exception as e:
        # Container might exist but we don't have permissions to create - try to proceed
        print(f"  Note: Could not create container ({e}), attempting upload anyway...")
    
    # Upload blob
    blob_client = container_client.get_blob_client(blob_name)
    
    content_settings = ContentSettings(content_type='image/png')
    blob_client.upload_blob(
        image_bytes, 
        overwrite=True,
        content_settings=content_settings
    )
    
    # Generate SAS URL with 10-year expiration for long-term access
    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.utcnow() + timedelta(days=3650)  # 10 years
    )
    
    # Return URL with SAS token
    return f"{blob_client.url}?{sas_token}"


def update_product_image_url(sku, image_url):
    """Update the product's image_url in the database."""
    from mssql_python import connect
    
    connection_string = (
        f"Server={os.getenv('AZURE_SQL_SERVER')};"
        f"Database={os.getenv('AZURE_SQL_DATABASE', 'productcatalog')};"
        f"Encrypt=yes;TrustServerCertificate=no;"
        f"Authentication=ActiveDirectoryInteractive"
    )
    
    with connect(connection_string) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE products SET image_url = ?, updated_at = GETUTCDATE() WHERE sku = ?",
            (image_url, sku)
        )
        conn.commit()


def process_product(product, dry_run=False):
    """Process a single product: generate image, upload, update DB."""
    sku = product['sku']
    name = product['name']
    
    print(f"\n{'='*60}")
    print(f"Processing: {name} ({sku})")
    print(f"{'='*60}")
    
    # Step 1: Generate prompt
    prompt = generate_image_prompt(product)
    print(f"  Prompt: {prompt[:100]}...")
    
    if dry_run:
        print("  [DRY RUN] Would generate image, upload, and update DB")
        return True
    
    try:
        # Step 2: Generate image with DALL-E
        print("  Generating image with DALL-E 3...")
        temp_url = generate_image_dalle(prompt)
        print(f"  ✓ Image generated")
        
        # Step 3: Download the image
        print("  Downloading image...")
        image_bytes = download_image(temp_url)
        print(f"  ✓ Downloaded ({len(image_bytes) / 1024:.1f} KB)")
        
        # Step 4: Upload to Blob Storage
        blob_name = f"products/{sku.lower()}.png"
        print(f"  Uploading to Blob Storage: {blob_name}")
        blob_url = upload_to_blob_storage(image_bytes, blob_name)
        print(f"  ✓ Uploaded: {blob_url}")
        
        # Step 5: Update database
        print("  Updating database...")
        update_product_image_url(sku, blob_url)
        print(f"  ✓ Database updated")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Error: {str(e)}")
        return False


def main():
    parser = argparse.ArgumentParser(description='Generate product images with DALL-E')
    parser.add_argument('--limit', type=int, default=None, 
                        help='Maximum number of products to process')
    parser.add_argument('--dry-run', action='store_true',
                        help='Show what would be done without making changes')
    parser.add_argument('--delay', type=int, default=5,
                        help='Delay between API calls in seconds (default: 5)')
    parser.add_argument('--regenerate-urls', action='store_true',
                        help='Regenerate SAS URLs for existing blobs (no DALL-E calls)')
    args = parser.parse_args()
    
    print("="*60)
    print("  Product Image Generation Script")
    print("  Azure OpenAI DALL-E → Azure Blob Storage → Azure SQL")
    print("="*60)
    
    # Validate environment variables
    required_vars = [
        'AZURE_SQL_SERVER',
    ]
    
    # Only require OpenAI if not just regenerating URLs
    if not args.regenerate_urls:
        required_vars.extend(['AZURE_OPENAI_ENDPOINT', 'AZURE_OPENAI_API_KEY'])
    
    storage_vars = ['AZURE_STORAGE_CONNECTION_STRING', 'AZURE_STORAGE_ACCOUNT']
    
    missing = [v for v in required_vars if not os.getenv(v)]
    if missing:
        print(f"\n✗ Missing required environment variables: {', '.join(missing)}")
        sys.exit(1)
    
    if not any(os.getenv(v) for v in storage_vars):
        print(f"\n✗ Need either AZURE_STORAGE_CONNECTION_STRING or AZURE_STORAGE_ACCOUNT")
        sys.exit(1)
    
    print(f"\nConfiguration:")
    print(f"  SQL Server: {os.getenv('AZURE_SQL_SERVER')}")
    if not args.regenerate_urls:
        print(f"  OpenAI Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
    print(f"  Storage: {os.getenv('AZURE_STORAGE_ACCOUNT', 'connection string')}")
    print(f"  Container: {os.getenv('AZURE_STORAGE_CONTAINER', 'product-images')}")
    print(f"  Dry Run: {args.dry_run}")
    print(f"  Regenerate URLs: {args.regenerate_urls}")
    
    # Step 1: Ensure image_url column exists (always needed for the query)
    add_image_url_column()
    
    # Handle URL regeneration mode
    if args.regenerate_urls:
        print("\nRegenerating SAS URLs for existing images...")
        products = get_all_products()
        
        if args.limit:
            products = products[:args.limit]
        
        success_count = 0
        error_count = 0
        
        for product in products:
            sku = product['sku']
            print(f"\n  {product['name']} ({sku})...", end=" ")
            
            if args.dry_run:
                print("[DRY RUN] Would regenerate URL")
                success_count += 1
                continue
            
            try:
                new_url = regenerate_sas_url(sku)
                if new_url:
                    update_product_image_url(sku, new_url)
                    print("✓")
                    success_count += 1
                else:
                    print("✗ No blob found")
                    error_count += 1
            except Exception as e:
                print(f"✗ Error: {e}")
                error_count += 1
        
        print("\n" + "="*60)
        print("  SUMMARY - URL Regeneration")
        print("="*60)
        print(f"  Processed: {len(products)}")
        print(f"  Success: {success_count}")
        print(f"  Errors/Missing: {error_count}")
        return
    
    # Step 2: Get products without images
    print("\nFetching products without images...")
    products = get_products_without_images()
    
    if args.limit:
        products = products[:args.limit]
    
    print(f"Found {len(products)} products to process")
    
    if not products:
        print("\n✓ All products already have images!")
        return
    
    # Step 3: Process each product
    success_count = 0
    error_count = 0
    
    for i, product in enumerate(products):
        if i > 0 and not args.dry_run:
            print(f"\nWaiting {args.delay}s before next request...")
            time.sleep(args.delay)
        
        if process_product(product, dry_run=args.dry_run):
            success_count += 1
        else:
            error_count += 1
    
    # Summary
    print("\n" + "="*60)
    print("  SUMMARY")
    print("="*60)
    print(f"  Processed: {len(products)}")
    print(f"  Success: {success_count}")
    print(f"  Errors: {error_count}")
    
    if args.dry_run:
        print("\n  [DRY RUN] No changes were made")


if __name__ == "__main__":
    main()
