CREATE TABLE Users (
    id INT PRIMARY KEY IDENTITY(1,1),
    sku VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) NOT NULL,
    tags NVARCHAR(255),
    stock INT NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    embeddings VARBINARY(MAX)
);