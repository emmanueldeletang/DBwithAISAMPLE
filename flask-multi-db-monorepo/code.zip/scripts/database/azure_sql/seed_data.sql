INSERT INTO users (sku, name, description, price, currency, tags, stock, created_at, embeddings) VALUES
('SKU001', 'Product 1', 'Description for Product 1', 19.99, 'USD', 'tag1,tag2', 100, GETDATE(), NULL),
('SKU002', 'Product 2', 'Description for Product 2', 29.99, 'USD', 'tag2,tag3', 50, GETDATE(), NULL),
('SKU003', 'Product 3', 'Description for Product 3', 39.99, 'USD', 'tag1,tag3', 75, GETDATE(), NULL);