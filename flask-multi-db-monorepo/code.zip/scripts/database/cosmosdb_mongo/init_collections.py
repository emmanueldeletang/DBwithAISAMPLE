from pymongo import MongoClient

def init_collections():
    client = MongoClient("your_connection_string_here")
    db = client["your_database_name"]

    collections = ["partners", "deliveries"]

    for collection in collections:
        if collection not in db.list_collection_names():
            db.create_collection(collection)
            print(f"Collection '{collection}' created.")
        else:
            print(f"Collection '{collection}' already exists.")

if __name__ == "__main__":
    init_collections()