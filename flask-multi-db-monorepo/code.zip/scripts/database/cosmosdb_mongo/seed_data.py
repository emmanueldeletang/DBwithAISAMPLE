from pymongo import MongoClient

def seed_data():
    client = MongoClient("your_cosmosdb_connection_string")
    db = client["your_database_name"]
    
    partners_collection = db["partners"]
    deliveries_collection = db["deliveries"]

    partners_data = [
        {"name": "Partner A", "contact": "contactA@example.com", "address": "123 Partner St"},
        {"name": "Partner B", "contact": "contactB@example.com", "address": "456 Partner Ave"},
    ]

    deliveries_data = [
        {"partner_id": 1, "delivery_date": "2023-10-01", "status": "Delivered"},
        {"partner_id": 2, "delivery_date": "2023-10-02", "status": "Pending"},
    ]

    partners_collection.insert_many(partners_data)
    deliveries_collection.insert_many(deliveries_data)

    print("Seed data inserted successfully.")

if __name__ == "__main__":
    seed_data()