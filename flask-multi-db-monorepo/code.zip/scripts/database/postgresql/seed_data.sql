INSERT INTO customers (name, email, created_at) VALUES
('John Doe', 'john.doe@example.com', NOW()),
('Jane Smith', 'jane.smith@example.com', NOW()),
('Alice Johnson', 'alice.johnson@example.com', NOW());

INSERT INTO orders (customer_id, product_id, quantity, order_date) VALUES
(1, 1, 2, NOW()),
(1, 2, 1, NOW()),
(2, 1, 3, NOW()),
(3, 3, 1, NOW());

INSERT INTO products (name, description, price, stock) VALUES
('Product A', 'Description for Product A', 19.99, 100),
('Product B', 'Description for Product B', 29.99, 50),
('Product C', 'Description for Product C', 39.99, 75);