from setuptools import setup, find_packages

setup(
    name='flask-multi-db-monorepo',
    version='0.1.0',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'Flask',
        'Flask-SQLAlchemy',
        'psycopg2-binary',
        'pymongo',
        'mssql-python',
        'azure-identity',
        'requests',
        'flask-cors',
        'python-dotenv',
        'openai',
    ],
    entry_points={
        'console_scripts': [
            'product-app=product_app.app:main',
            'order-app=order_app.app:main',
            'logistics-app=logistics_app.app:main',
        ],
    },
)